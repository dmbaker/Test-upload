# DMBTools Toolkit

![image info](./dmbtools/resources/dmbtools.png)

Subset of tools from the DMBTools toolkit.  This set revolves around geodesy, math and geometry utilities, wellbore positioning, and includes the normalized landing point and the horizontal stats pak calculations.

Note: The initial version of dmbtools_1_0_0_1 is the version from the Dallas MTC egg file.  The egg file was built from the original, private, dmbtools package.

## Modules

- ### geodetic

        Utilities for geodetic reference and calculations

  - #### projection
  
        Methods for basic coordinate conversions, working with and discovering EPSG codes and State Plane systems from API numbers, and calculating grid convergence.

  - #### convert

        Methods for basic lat/lon conversions, working with datums and calculating bottom hole locations accounting for grid convergence

  - #### zmap
  
        A class for reading ZMap+ files.

- ### geometry

        Utilities for doing geometric calculations

- ### math

        Utilities for doing specialized math calculations

- ### recipes

        Various methods to solve technical problems such as Cartesian Products

- ### wellbore

        Methods related to wellbore geometry and positioning

  - #### survey
  
        Methods methods to calculate wellbore positions logs using the Arc-2-Chord method of minimum curvature, including interpolation and projection to bit

  - #### normalized_landing_point

        A unique and statically consistent method for finding measured depth of the landing point in J-shaped and pitchfork-shaped wellbores using only the deviation surveys

  - #### horizontal_stats_pak

        Using the normalized landing point measured, methods to calculate statistics of the lateral portion of the wellbore, including the best fit line, mean azimuth and inclination, basic tortuosity, sinuosity and undulation

  - #### tortuosity

        Multiple methods for calculating a tortuosity index of a wellbore.  Includes the most recent version developed by Angus Jameson
