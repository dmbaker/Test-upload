import os
from setuptools import setup, find_packages
import pathlib

# to install, run this from the command line in the same directory
# as this setup.p file.
#
# python setup.py bdist_wheel --universal

# Utility function to read the README file.
# Used for the long_description.  It's nice, because now 1) we have a top level
# README file and 2) it's easier to type in the README file than to put a raw
# string in below ...
def read(fname):
    here = pathlib.Path(__file__).parent.resolve()
    return open(os.path.join(here, fname)).read()

setup(
    name = "dmbtools",
    version = "2.0.3",
    author = "David M. Baker",
    author_email = "dbaker@concho.com",
    description = ("A subset of tools from the DMBTools toolkit."),
    long_description=read('README.md'),
    keywords = "geodesy math geometry wellbore positioning normalized landing point horizontal stats pak",
    packages=find_packages(), #['geodetic', 'geometry', 'math', 'recipes', 'wellbore'],
    package_data={'dmbtools': ['resources/fips_api_spc_epsg_utm_cross_ref.csv']},
    install_requires=['numpy', 'pandas', 'pyproj'],
    classifiers=[
        "Development Status :: 2 - Production",
        "Topic :: Utilities",
    ]
)