import numpy

# https://stackoverflow.com/questions/11144513/numpy-cartesian-product-of-x-and-y-array-points-into-single-array-of-2d-points/11146645#11146645

def cartesian_product(*arrays):
    la = len(arrays)
    dtype = numpy.result_type(*arrays)
    arr = numpy.empty([len(a) for a in arrays] + [la], dtype=dtype)
    for i, a in enumerate(numpy.ix_(*arrays)):
        arr[...,i] = a
    return arr.reshape(-1, la)

def unique_pairs(a, b, diagonal=False):
    """
    Given two 1d arrays find all unique pairs of numbers where the
    order of the numbers of each pair in not unique, for example,
    [2,3] and [3,2] are the same.
    diagonal: if true, include pairs where the values are the same, e.g., [0, 0].
    """
    a = numpy.atleast_1d(a)
    b = numpy.atleast_1d(b)
    
    assert (a.ndim == 1 and b.ndim == 1), 'Arrays a and be must be one dimensional.'
    
    cp = cartesian_product(a, b)
    return cp if diagonal else cp[cp[:,0] != cp[:,1]]