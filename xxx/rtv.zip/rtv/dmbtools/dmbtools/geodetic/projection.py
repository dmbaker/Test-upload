import numpy as np
import pyproj
from ..math.utils import modulus
from ..geometry.utils import rtv

class Project():
    """
    A projection class that assumes all inputs and outputs are tuples of 
        Northings/Latitudes(degrees) and Eastings/Longitudes(degrees) and
        optionally verticals.
    """
    def __init__(self, from_epsg, to_epsg):
        self.from_epsg  = from_epsg
        self.to_epsg    = to_epsg
        self._from_proj = pyproj.Proj(f'epsg:{from_epsg}')
        self._to_proj   = pyproj.Proj(F'epsg:{to_epsg}')
    
    def forward(self, nev):
        """
        nev: a list of tuples on nev coordinates.
        """
        return Project.swap_cols(list(pyproj.itransform(self._from_proj, self._to_proj, Project.swap_cols(nev), always_xy=True)))
    
    def inverse(self, nev):
        """
        nev: a list of tuples on nev coordinates.
        """
        return Project.swap_cols(list(pyproj.itransform(self._to_proj, self._from_proj, Project.swap_cols(nev), always_xy=True)))

    def __str__(self): 
       return f'from: \n{self._from_proj.crs.__repr__()} \nto: \n{self._to_proj.crs.__repr__()}'
    
    @classmethod
    def swap_cols(cls, ll):
        ll2 = np.array(ll, copy=True)
        if ll2.shape[1] > 2:
             Exception('Project.swap_cols: The input array must only have two columns')
        ll2[:,0], ll2[:,1] = ll2[:,1], ll2[:,0].copy()
        return ll2

def get_epsg_name(epsg_code):
    return pyproj.CRS(f'epsg:{epsg_code}').name

def get_epsg_names(epsg_code_list):
    return {epsg_code: pyproj.CRS(f'epsg:{epsg_code}').name for epsg_code in epsg_code_list}

class GridConvergenceException(Exception):
    pass

class GridConvergence():
    """
    Calculate the grid convergence at a given lat/lon.
    """
    def __init__(self, geog_epsg, proj_epsg):
        """
        geog_epsg: a geographic epsg code
        proj_epsg: a projected epsg code
        """
        self.geog_epsg  = geog_epsg
        self.proj_epsg  = proj_epsg
        self.delta = 1.0 / 111000.0
        self._prj = Project(self.geog_epsg, self.proj_epsg)
    
    def calc(self, nev):
        """
        nev: an array of tuples of lat, lon and optionally a vertical.
        """
        if len(nev[0]) == 3:
            ng = np.array(nev)[:,:-1].copy()
            sg = np.array(nev)[:,:-1].copy()
        else:
            ng = np.array(nev).copy()
            sg = np.array(nev).copy()
        ng[:,0] += self.delta # add to lat
        sg[:,0] -= self.delta # subtract from lat
        nc = self._prj.forward(ng) # project the north point
        sc = self._prj.forward(sg) # project the south point
        try:
            sn = nc - sc # get the north pointing projected geodesic
        except Exception as ex:
            raise GridConvergenceException(ex)
        theta = np.arctan2(sn[:,0], sn[:,1]) # recall sn is (northing, easting)
        theta -= np.pi / 2.0
        return np.rad2deg(theta)

def toTrueNorthNEVold(nev, lat, lon, geog_epsg, proj_epsg, forward=False):
    """
    Rotates a set of grid north offset coordinates relative to the passed lat / lon
    to true north.
    nev: a 2D array of north, east and vertical (tvd) offset coordinates.
    The offsets are relative to rig datum, e.g, the kelly bushing and
    are assumed be relative to true north.
    lat: the latitude, in degrees, of the rig datum.
    lon: the longitude, in degrees of the rig datum.
    geog_epsg: the epsg code of the lat / lon values.
    proj_epsg: the epsg code of the grid CRS of nev values.
    forward: if true, rotates from true north to grid north.
    returns the nev array rotated to be relative to true north.
    """

    theta = np.deg2rad(GridConvergence(geog_epsg, proj_epsg).calc([[lat, lon]]))[0] # get the grid convergence
    theta = -theta if forward else theta
    print(theta)
    c, s = np.cos(theta), np.sin(theta) 
    R = np.array(((c, -s), (s, c))) # build the rotation matrix. a positive thata will rotate clockwise
    rnev = np.array(nev, copy=True)
    rnev[:,:2] = R.dot(nev[:,:2].T).T # do the rotation
    return rnev

def toTrueNorthNEV(nev, lat, lon, geog_epsg, proj_epsg, forward=False):
    """
    Rotates a set of grid north offset coordinates, relative to the passed lat / lon,
    to true north.
    nev: a 3D array of north, east and vertical (tvd) offset coordinates.
    The offsets are relative to rig datum, e.g, the kelly bushing and
    are assumed be relative to true north.
    lat: the latitude, in degrees, of the rig datum.
    lon: the longitude, in degrees of the rig datum.
    geog_epsg: the epsg code of the lat / lon values.
    proj_epsg: the epsg code of the grid CRS of nev values.
    forward: if true, rotates from true north to grid north.
    returns the nev array rotated to be relative to true north.
    """

    theta = np.deg2rad(GridConvergence(geog_epsg, proj_epsg).calc([[lat, lon]]))[0] # get the grid convergence
    theta = -theta if forward else theta
    ui = np.array([1.0, 0.0, 0.0]) # north pointing unit vector
    uf = np.array([np.cos(theta), np.sin(theta), 0.0]) # grid north vector
    return rtv(ui, uf, np.array(nev, copy=True))

def toTrueNorthAZI(azi, lat, lon, geog_epsg, proj_epsg, forward=False):
    """
    Adjusts a set a grid north azimuths to true north.
    azi: a 1D array of azimuths, degrees, to correct to true north.
    lat: the latitude, in degrees, of the rig datum.
    lon: the longitude, in degrees of the rig datum.
    geog_epsg: the epsg code of the lat / lon values.
    proj_epsg: the epsg code of the grid CRS of nev values.
    forward: if true, rotates from true north to grid north.
    returns the azi array corrected to true north.
    """

    theta = GridConvergence(geog_epsg, proj_epsg).calc([[lat, lon]]) # get the grid convergence
    theta = -theta if forward else theta
    razi = np.array(azi, copy=True)
    razi += theta
    return modulus(razi, 360.0)

class LatLonException(Exception):
    """
    Exception raised when the latitude or longitude is out of range.
    """
    pass

def test_lat_lon(lat_deg, lon_deg):
    if np.abs(lat_deg) > 90.0:
        raise LatLonException(f'The latitude: {lat_deg} is out of range. ({lat_deg}, {lon_deg})')
    if np.abs(lon_deg) > 180.0:
        raise LatLonException(f'The longitude: {lon_deg} is out of range. ({lat_deg}, {lon_deg})')