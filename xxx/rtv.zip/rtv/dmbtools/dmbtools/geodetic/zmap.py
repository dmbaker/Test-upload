import numpy as np

class ZMapPlus(object):
    """
    A class to read and hold a ZMpap+ grid file.
    data: string, full path and filename to the grid file,
        or a list of lines from a ZMpap+ grid file.
    crs: int, the EPSG code of the grid data.
    load_from_file: bool, if true (default) then data is a filename,
        otherwise data is a list of lines from a ZMpap+ grid file.
    """
    def __init__(self, data, crs=-1, load_from_file=True, as_masked=False):
        self.as_masked = as_masked
        self.filepath = data if load_from_file else ''
        self.data = self._load_from_file() if load_from_file else data
        self.crs = crs
        self._max_header_lines = 20
        self._is_loaded = False
        self.load_from_file = load_from_file
    
    def _load_from_file(self):
        with open(self.filepath) as f:
            return f.read().splitlines()
    
    def _read_header(self):
        self.hdr = []
        in_hdr = False
        is_grid = False
        for i in range(self._max_header_lines):
            line = self.data[i]
            self.hdr.append(line)
            if line.startswith('@'):
                if not is_grid and 'GRID' in line.upper():
                    is_grid = True
                if in_hdr:
                    break
                in_hdr = True
        
        assert (in_hdr), "End of header section not found..."
        assert (is_grid), "The file is not a ZMapPlus GRID file..."
        
        self.hdr_cnt = len(self.hdr)
        self.sub_hdr = []
        for line in self.hdr:
            if not (line.startswith('@') or line.startswith('!') or line.strip() == ''):
                self.sub_hdr.append(line)
        
        self.sub_hdr = ','.join(self.sub_hdr).split(',')
        self.null = np.nan if self.sub_hdr[1].strip() == '' else np.float(self.sub_hdr[1])
        self.xmin, self.xmax, self.ymin, self.ymax = [np.float(x) for x in self.sub_hdr[7:11]]
        self.grid_rows, self.grid_cols = [np.int(y) for y in self.sub_hdr[5:7]]
        self.x_spcng = (self.xmax - self.xmin) / self.grid_cols
        self.y_spcng = (self.ymax - self.ymin) / self.grid_rows
    
    def _read_data(self):
        self.grid = ((np.asarray([word for line in self.data[self.hdr_cnt:] for word in line.split()]).astype(float))
                        .reshape(self.grid_cols, self.grid_rows).T)
        self.grid[self.grid==self.null] = np.nan
        if self.as_masked:
            self.grid = np.ma.array(self.grid, mask=np.isnan(self.grid))
    
    def read(self):
        if not self._is_loaded:
            self._read_header()
            self._read_data()
            self._is_loaded = True
    
    def get_value(self, x, y):
        """
        x: also easting
        y: also northing
        """
        try:
            row_i = (self.grid_rows - 1)  - int((y - self.xmin) / self.y_spcng)
            col_i = int((x - self.xmin) / self.x_spcng)
            if row_i < 0 or col_i < 0:
                return np.nan
            return self.grid[row_i, col_i]
        except:
            return np.nan
    
    @classmethod
    def load(cls, filepath, crs=-1, load_from_file=True, as_masked=False):
        zmp = cls(filepath, crs, load_from_file, as_masked)
        zmp.read()
        return zmp

