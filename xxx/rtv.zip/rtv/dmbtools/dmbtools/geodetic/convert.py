import os
import numpy as np
import pandas as pd
import pkg_resources as pr
from .projection import Project, toTrueNorthNEV

def decdeg2dms(dd):
    """
    Convert from decimal degrees to degrees minutes seconds.
    """
    is_positive = dd >= 0
    dd = abs(dd)
    minutes, seconds = divmod(dd * 3600.0, 60.0)
    degrees, minutes = divmod(minutes, 60.0)
    degrees = degrees if is_positive else -degrees
    return (degrees, minutes, seconds)

def dms2decdeg(d, m, s):
    """
    Convert from degrees to degrees minutes seconds to decimal degrees
    """
    return - (s/3600.0) - (m/60.0) + d if d < 0 else (s/3600.0) + (m/60.0) + d

def get_fips_api_spc_epsg_utm_cross_ref():
    filename = pr.resource_filename('dmbtools', 'resources/fips_api_spc_epsg_utm_cross_ref.csv')
    flds = ['STFIPS', 'COFIPS', 'FIPS', 'STAPI', 'COAPI', 'UTM', 'SPC27', 'SPC83']
    types = {fld: object for fld in flds}
    return pd.read_csv(filename, dtype=types)

def wai():
    print(pr.resource_filename('dmbtools', 'resources/fips_api_spc_epsg_utm_cross_ref.csv')) #

def api_num_2_epsg(apinums, nad27=True):
    """
    Given a list of api numbers, return dataframe epsg codes the api's are located in.
    """
    parsed = [[api, api[:2], api[2:5]] for api in apinums]
    cols = ['API', 'STAPI', 'COAPI']
    #types = {fld: object for fld in cols}
    apis = pd.DataFrame(parsed, columns=cols, dtype=str)
    if nad27:
        codes = get_fips_api_spc_epsg_utm_cross_ref()[['STAPI', 'COAPI', 'EPSG_NAD27']]
        codes = codes.rename(index=str, columns={'EPSG_NAD27': 'EPSG_CODE'})
    else:
        codes = get_fips_api_spc_epsg_utm_cross_ref()[['STAPI', 'COAPI', 'EPSG_NAD83']]
        codes = codes.rename(index=str, columns={'EPSG_NAD83': 'EPSG_CODE'})
    return apis.merge(codes, on=['STAPI', 'COAPI']).set_index(['API'])['EPSG_CODE']

class DatumError(Exception):
    pass

class Datums:
    """
    Standard US datums.  All values are in meters.
    """
    def __init__(self, datum='nad27'):
        if datum.lower() == 'nad27':
            self.name = 'nad27'
            self.epsg = 4267
            self.a = 6378206.4 # semi-major axis
            self.b = 6356583.8 # semi-minor axis
            self.inv_flat = 1.0 / ((self.a - self.b) / self.a)
        elif datum.lower() == 'nad83':
            self.name = 'nad83'
            self.epsg = 4269
            self.a = 6378137.0
            self.inv_flat = 298.257222101
            self.b = self.a * (1.0 - (1.0 / self.inv_flat)) # self.a / (1.0 - (1.0 / self.inv_flat))
        elif datum.lower().replace(" ", "") == 'wgs84':
            self.name = 'wgs 84'
            self.epsg = 4326
            self.a = 6378137.0
            self.inv_flat = 298.257223563
            self.b = self.a * (1.0 - (1.0 / self.inv_flat)) # self.a / (1.0 - (1.0 / self.inv_flat))
        else:
            raise DatumError('Unsupported datum reference.')

    def f(self):
        return (self.a - self.b) / self.a # flattting
    
    def m(self):
        return 1.0 / self.f # inverse flatting

    def rf(self):
        return self.inv_flat # inverse flatting

    def e2(self):
        return 1.0 - (np.power(self.b, 2) / np.power(self.a, 2)) # eccentricity squared

    def esqrd_noel(self):
        return (np.power(self.a, 2.0) - np.power(self.b, 2.0)) / np.power(self.a, 2.0) # eccentricity squared

    def r(self, lat):
        """
        Radius in the meridian
        """
        return (self.a * (1.0 - self.e2())) / np.power(np.sqrt(1.0 - self.e2() * np.power(np.sin(lat), 2.0)), 3.0)
    
    def rho(self, lat):
        """
        Radius of curvature in the meridian
        """
        return (self.a * (1.0 - self.e2())) / np.power(1.0 - self.e2() * np.power(np.sin(lat), 2.0), 3.0 / 2.0)

    def n(self, lat):
        """
        Radius in the prime vertical
        """
        return self.a / np.sqrt(1.0 - self.e2() * np.power(np.sin(lat), 2))
    
    def rcip(self, lat):
        """
        Radius of curvature in the parallel 
        """
        return self.n(lat) * np.cos(lat)


def meters2feet(meters):
    return np.multiply((1.0/0.3048), meters)

def feet2meters(feet):
    return np.multiply(0.3048, feet)

def meters2ftus(meters):
    return np.multiply((3937.0/1200.0), meters)

def ftus2meters(usft):
    return np.multiply((1200.0/3937.0), usft)

def lmp(nev, lat, lon, datum='nad27'):
    """
    Calculate the latitude and longitude of a wellbore position log
    using the method developed by Noel Zinn:
    "Accounting for Earth Curvature in Directional Drilling"
    nev: a #D array of north, east and vertical (tvd) offset coordinates.
    The offsets are relative to rig datum, e.g, the kelly bushing and
    are assumed be relative to true north.
    lat: the latitude, in degrees, of the rig datum.
    lon: the longitude, in degrees of the rig datum.
    datum: string value specifing the geographic datum of the 
    lat / lon values.
    Returns a 2D array latitude and longitude coordinates of each 
    offset position.
    """

    rad = 180.0 / np.pi
    dtm = Datums(datum)
    latlon = np.zeros([len(nev), 2])
    Ndeplast = nev[0, 0]
    Edeplast = nev[0, 1]
    latlast = lat
    lonlast = lon
    for dex in np.arange(len(nev)):
        LATRAD = latlast / rad
        R = dtm.r(LATRAD)
        N = dtm.n(LATRAD)
        Ndep = nev[dex, 0]
        Edep = nev[dex, 1]
        TVD =  nev[dex, 2]
        dNdep = Ndep - Ndeplast
        dEdep = Edep - Edeplast
        Ndeplast = Ndep
        Edeplast = Edep
        dlat = rad * (dNdep / (R - TVD))
        dlon = rad * (dEdep / (N - TVD) / np.cos(LATRAD))
        _lat = latlast + dlat
        _lon = lonlast + dlon
        latlast = _lat
        lonlast = _lon
        latlon[dex, 0] = _lat
        latlon[dex, 1] = _lon
    
    return latlon

def forward_lat_lon(nev, lat, lon, geog_crs_epsg, proj_crs_epsg, true_north=True):
    """
    Use forward projection to calc the latiute and longitude of nev offsets
    that are relative to the passed lat, lon values.
    This method does not account for the curvature along the ellipsoid,
    that is, no scale factor is applied to the distance to account for the
    curvature.  Nor does it account for elevation reduction due to depth
    differences in the vertical, and, no Laplace correction is applied.
    nev: a 3D array of north, east and vertical (tvd) offset coordinates.
    The offsets are relative to rig datum, e.g, the kelly bushing and
    are assumed be relative to true north.
    lat: the latitude, in degrees, of the rig datum.
    lon: the longitude, in degrees of the rig datum.
    geog_crs_epsg: int, the epsg code of the geographic system of the lat/lon values.
    proj_crs_epsg: int, the epsg code to use to forward project the lat/lon to.
    true_north: bool, indicates if the nev offest values are relative to true north;
    default is True.
    return_cart: bool, flag to return nev_geog, nev_cart otherwise nev_geog;
    default is False
    Returns a 3D array latitude and longitude coordinates of each 
    offset position.
    """
    if true_north:
        # if the nev's are relative to true north we need to rotate the vectors
        # to be relative to the projected crs we will use to forward project the offests
        nev = toTrueNorthNEV(nev, lat, lon, geog_crs_epsg, proj_crs_epsg, forward=True)
    
    proj = Project(geog_crs_epsg, proj_crs_epsg) # setup the forward projection
    surf_proj = proj.forward([[lat, lon]])[0] # get the surface projected coordinates
    surf_cart = np.array([surf_proj[0], surf_proj[1], 0.0]) # the projected surface location, just n and e
    nev_cart = nev + surf_cart # move the offsets in projected horizontal coordinates, leave the verticals as is
    ne_cart = nev_cart[:,0:2]
    v_cart = nev[:,-1]
    ne_geog = proj.inverse(ne_cart) # invert the coordinates to get the lat/lon's
    nev_geog = np.column_stack((ne_geog, v_cart))
    return nev_geog, nev_cart
