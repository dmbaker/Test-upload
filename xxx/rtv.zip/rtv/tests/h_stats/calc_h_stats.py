from operator import imod
import os
import sys
import glob
import datetime
import contextlib
import numpy as np
from numpy.lib.function_base import copy
import pandas as pd
import traceback
import pyodbc 
import textwrap
import joblib
import warnings
from joblib import Parallel, delayed
from dmbtools.wellbore import horizontal_stats_pak as hstats
from dmbtools.geodetic import convert as cvt
from dmbtools.geodetic import projection as prj
from dmbtools.wellbore.survey import position_log
from json_environ import Environ

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
env_path = os.path.join(BASE_DIR, '.my_env.json')
env = Environ(path=env_path)

DEBUG = env("DEBUG")
JOBS = env("JOBS")
RAISE_EXCEPTION = False # raise error when calculateing h_stats, otherwise, just report and write exception 

NOTEBOOK = False
if NOTEBOOK:
    from tqdm.notebook import tqdm
else:
    from tqdm import tqdm

@contextlib.contextmanager
def tqdm_joblib(tqdm_object):
    """
    Context manager to patch joblib to report into tqdm progress bar given as argument
    """
    class TqdmBatchCompletionCallback(joblib.parallel.BatchCompletionCallBack):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def __call__(self, *args, **kwargs):
            tqdm_object.update(n=self.batch_size)
            return super().__call__(*args, **kwargs)

    old_batch_callback = joblib.parallel.BatchCompletionCallBack
    joblib.parallel.BatchCompletionCallBack = TqdmBatchCompletionCallback
    try:
        yield tqdm_object
    finally:
        joblib.parallel.BatchCompletionCallBack = old_batch_callback
        tqdm_object.close()    

class Database():
    def __init__(self, conn_str, **kwargs):
        """
        conn_str: string, the connections string.
        kwargs: dict of kwargs passed to the connect method.
        """
        self.__conn_str = conn_str
        self.__cnxn = pyodbc.connect(self.__conn_str, autocommit=True, **kwargs)
        
    @property
    def connection(self):
        return self.__cnxn
    
    def run(self, sql, params=[]):
        with self.connection as conn:
            return pd.read_sql(textwrap.dedent(sql), conn, coerce_float=True, params=params)

def calc_h_stats(srv, tie_in, lat, lon, horizontal_stats_cols, max_inc):
    try:
        prj.test_lat_lon(lat, lon)
        stats = hstats.horizontal_stats(srv, tie_in, max_inc=max_inc)
        error = 'OK'
    except Exception as ex:
        stats = np.full((len(horizontal_stats_cols)), np.nan)
        flag = "PRG_ERR: " + ''.join(traceback.format_exception(
                                                    etype=type(ex),
                                                    value=ex,
                                                    tb=ex.__traceback__
                                                    ))
        if RAISE_EXCEPTION:
            raise Exception(flag)

        error = str(ex)
        
    return stats, error

def calc_meta(one_stat, uwi, gov_id, elev, error, mod_date):
    """
    Set the basic metadata for this wellbore's stats
    """
    one_stat['uwi'] = uwi
    one_stat['gov_id'] = gov_id
    one_stat['elev'] = elev
    one_stat['src'] = 'dmbtools'
    one_stat['error'] = error
    one_stat['mod_date'] = mod_date

def calc_mid(one_stat):
    """
    Calc the midpoint of the mean lateral path of this wellbore
    """
    mean_dir = np.array([one_stat['mean_dir_n'], one_stat['mean_dir_e'], one_stat['mean_dir_v']])
    mean_bgn = np.array([one_stat['mean_bgn_n'], one_stat['mean_bgn_e'], one_stat['mean_bgn_v']])
    #mean_end = np.array([one_stat['mean_end_n'], one_stat['mean_end_e'], one_stat['mean_end_v']])
    mean_len = one_stat['mean_len']
    mean_mid = mean_bgn + (0.5 * mean_len * mean_dir)
    one_stat['mean_mid_n'] = mean_mid[0]
    one_stat['mean_mid_e'] = mean_mid[1]
    one_stat['mean_mid_v'] = mean_mid[2]
    return mean_mid

def calc_lat_lon(one_stat, gov_id, elev, lat, lon):
    """
    Calc the lat/lon's of our key postions in our hStats
    """
    prefixes = ['nlp', 'td', 'mean_bgn', 'mean_mid', 'mean_end']
    points = [np.array([one_stat[prefix + '_n'], one_stat[prefix + '_e'], one_stat[prefix + '_v'] - elev]) for prefix in prefixes]
    geog_crs_epsg = cvt.Datums(datum='nad27').epsg
    proj_crs_epsg = cvt.api_num_2_epsg([gov_id], nad27=True).iloc[0]
    forward, _ = cvt.forward_lat_lon(points, lat, lon, geog_crs_epsg, proj_crs_epsg, true_north=True)
    
    def add_prefix(frwd, prefix):
        one_stat[prefix + '_lat'] = frwd[0]
        one_stat[prefix + '_lon'] = frwd[1]
        one_stat[prefix + '_vss'] = frwd[2]
    
    [add_prefix(forward[i], prefixes[i]) for i in range(len(prefixes))]
    
    return

def full_stats_meta():
    full_stats_cols = [
    'uwi',
    'gov_id',
    'src',
    'elev',
    'nlp_md',
    'nlp_n',
    'nlp_e',
    'nlp_v',
    'nlp_lat',
    'nlp_lon',
    'nlp_vss',
    'td_n',
    'td_e',
    'td_v',
    'td_lat',
    'td_lon',
    'td_vss',
    'mean_bgn_n',
    'mean_bgn_e',
    'mean_bgn_v',
    'mean_bgn_lat',
    'mean_bgn_lon',
    'mean_bgn_vss',
    'mean_mid_n',
    'mean_mid_e',
    'mean_mid_v',
    'mean_mid_lat',
    'mean_mid_lon',
    'mean_mid_vss',
    'mean_end_n',
    'mean_end_e',
    'mean_end_v',
    'mean_end_lat',
    'mean_end_lon',
    'mean_end_vss',
    'mean_dir_n',
    'mean_dir_e',
    'mean_dir_v',
    'mean_inc',
    'mean_azi',
    'mean_len',
    'lateral_len',
    'tortuosity',
    'sinuosity',
    'undulation',
    'error',
    'mod_date']
    return full_stats_cols

def sql_statements(well_dir_survey_station, wellbore, inc=None, ekey=None):
    all_surveys_sql = f'''
    SELECT DISTINCT
          EKEY_WELLBORE
        , MEASURED_DEPTH
        , INCLINATION
        , AZIMUTH
    FROM [PPDM38].[dbo].[{well_dir_survey_station}]
    ORDER BY EKEY_WELLBORE
        , MEASURED_DEPTH
    '''
    # ekeys_sql_old = f'''
    # SELECT DISTINCT EKEY_WELLBORE
    # FROM [PPDM38].[dbo].[{well_dir_survey_station}]
    # WHERE INCLINATION >= ?
    # '''
    all_ekeys_sql = f'''
    WITH C AS
        (SELECT
            ROW_NUMBER() OVER(PARTITION BY [EKEY_WELLBORE] 
                                  ORDER BY [MEASURED_DEPTH] ASC) AS ROW
            ,EKEY_WELLBORE
            ,ROW_CHANGED_DATE
         FROM [PPDM38].[dbo].[{well_dir_survey_station}] WITH (NOLOCK)
         WHERE INCLINATION >= ?),
         A AS
        (SELECT * 
         FROM C
         WHERE C.ROW = 1)
    SELECT 
         A.EKEY_WELLBORE
        ,A.ROW_CHANGED_DATE
    FROM A
    INNER JOIN [PPDM38].[dbo].[{wellbore}] B WITH (NOLOCK)
    ON A.EKEY_WELLBORE = B.EKEY_WELLBORE
    '''
    one_survey_sql = f'''
    SELECT DISTINCT
          EKEY_WELLBORE
        , MEASURED_DEPTH
        , INCLINATION
        , AZIMUTH
    FROM [PPDM38].[dbo].[{well_dir_survey_station}] WITH (NOLOCK)
    WHERE EKEY_WELLBORE = ?
    ORDER BY MEASURED_DEPTH
    '''
    one_survey_sql_x = f'''
    SELECT DISTINCT
          EKEY_WELLBORE
        , MEASURED_DEPTH
        , INCLINATION
        , AZIMUTH
    FROM [PPDM38].[dbo].[{well_dir_survey_station}] WITH (NOLOCK)
    WHERE EKEY_WELLBORE = '{ekey}'
    ORDER BY MEASURED_DEPTH
    '''
    one_tie_in_sql = f'''
    WITH C AS
        (SELECT
            ROW_NUMBER() OVER(PARTITION BY [EKEY_WELLBORE] 
                                  ORDER BY [MEASURED_DEPTH] ASC) AS ROW
            ,EKEY_WELLBORE
            ,LATITUDE
            ,LONGITUDE
            ,Y_OFFSET * IIF(NS_DIRECTION = 'N', 1, -1) AS "N_OFFSET"
            ,X_OFFSET * IIF(EW_DIRECTION = 'E', 1, -1) AS "E_OFFSET"
            ,TVD
            ,ROW_CHANGED_DATE
         FROM [PPDM38].[dbo].[{well_dir_survey_station}] WITH (NOLOCK)
         WHERE INCLINATION >= 0.0),
         A AS
        (SELECT * 
         FROM C
         WHERE C.ROW = 1)
    SELECT 
         A.EKEY_WELLBORE
        ,B.GOVERNMENT_ID
        ,B.DEPTH_DATUM_ELEV
        ,A.LATITUDE
        ,A.LONGITUDE
        ,A.N_OFFSET
        ,A.E_OFFSET
        ,A.TVD
        ,A.TVD - B.DEPTH_DATUM_ELEV AS TVDSS
        ,A.ROW_CHANGED_DATE
    FROM A
    INNER JOIN [PPDM38].[dbo].[{wellbore}] B WITH (NOLOCK)
    ON A.EKEY_WELLBORE = B.EKEY_WELLBORE
    WHERE A.EKEY_WELLBORE = ?
    '''
    one_tie_in_sql_x = f'''
    WITH C AS
        (SELECT
            ROW_NUMBER() OVER(PARTITION BY [EKEY_WELLBORE] 
                                  ORDER BY [MEASURED_DEPTH] ASC) AS ROW
            ,EKEY_WELLBORE
            ,LATITUDE
            ,LONGITUDE
            ,Y_OFFSET * IIF(NS_DIRECTION = 'N', 1, -1) AS "N_OFFSET"
            ,X_OFFSET * IIF(EW_DIRECTION = 'E', 1, -1) AS "E_OFFSET"
            ,TVD
            ,ROW_CHANGED_DATE
         FROM [PPDM38].[dbo].[{well_dir_survey_station}] WITH (NOLOCK)
         WHERE INCLINATION >= 0.0),
         A AS
        (SELECT * 
         FROM C
         WHERE C.ROW = 1)
    SELECT 
         A.EKEY_WELLBORE
        ,B.GOVERNMENT_ID
        ,B.DEPTH_DATUM_ELEV
        ,A.LATITUDE
        ,A.LONGITUDE
        ,A.N_OFFSET
        ,A.E_OFFSET
        ,A.TVD
        ,A.TVD - B.DEPTH_DATUM_ELEV AS TVDSS
        ,A.ROW_CHANGED_DATE
    FROM A
    INNER JOIN [PPDM38].[dbo].[{wellbore}] B WITH (NOLOCK)
    ON A.EKEY_WELLBORE = B.EKEY_WELLBORE
    WHERE A.EKEY_WELLBORE = '{ekey}'
    '''
    all_tie_in_sql = f'''
    WITH C AS
        (SELECT
            ROW_NUMBER() OVER(PARTITION BY [EKEY_WELLBORE] 
                                  ORDER BY [MEASURED_DEPTH] ASC) AS ROW
            ,EKEY_WELLBORE
            ,LATITUDE
            ,LONGITUDE
            ,Y_OFFSET * IIF(NS_DIRECTION = 'N', 1, -1) AS "N_OFFSET"
            ,X_OFFSET * IIF(EW_DIRECTION = 'E', 1, -1) AS "E_OFFSET"
            ,TVD
            ,ROW_CHANGED_DATE
         FROM [PPDM38].[dbo].[{well_dir_survey_station}]
         WHERE INCLINATION >= ?),
         A AS
        (SELECT * 
         FROM C
         WHERE C.ROW = 1)
    SELECT 
         A.EKEY_WELLBORE
        ,B.GOVERNMENT_ID
        ,B.DEPTH_DATUM_ELEV
        ,A.LATITUDE
        ,A.LONGITUDE
        ,A.N_OFFSET
        ,A.E_OFFSET
        ,A.TVD
        ,A.TVD - B.DEPTH_DATUM_ELEV AS TVDSS
        ,A.ROW_CHANGED_DATE
    FROM A
    INNER JOIN [PPDM38].[dbo].[{wellbore}] B
    ON A.EKEY_WELLBORE = B.EKEY_WELLBORE
    '''
    statements = {
                 'all_ekeys_sql': all_ekeys_sql, 
                 'one_survey_sql': one_survey_sql, 
                 'one_survey_sql_x': one_survey_sql_x, 
                 'one_tie_in_sql': one_tie_in_sql, 
                 'one_tie_in_sql_x': one_tie_in_sql_x,
                 'all_tie_in_sql': all_tie_in_sql, 
                 'all_surveys_sql': all_surveys_sql
                }
    return statements

class tdm_wellbore_data():
    def __init__(self, 
                 conn_str, 
                 well_dir_survey_station, 
                 wellbore, 
                 select_inc=70, 
                 nlp_inc=84):

        self.conn_str = conn_str
        self.well_dir_survey_station = well_dir_survey_station
        self.wellbore = wellbore
        self.select_inc = select_inc
        self.nlp_inc = nlp_inc

    def get_tdm_wellbore(self, ekey):
        sql = sql_statements(self.well_dir_survey_station, self.wellbore, self.select_inc, ekey)
        
        db = Database(self.conn_str)
        survey = db.run(sql['one_survey_sql_x']) #db.run(sql['one_survey_sql'], params=[ekey])
        header = db.run(sql['one_tie_in_sql_x']) #db.run(sql['one_tie_in_sql'], params=[ekey])
        
        rec = header.iloc[0]
        wb = wellbore(
            uwi = ekey,
            gov_id = rec['GOVERNMENT_ID'],
            elev = rec['DEPTH_DATUM_ELEV'],
            lat = rec['LATITUDE'],
            lon = rec['LONGITUDE'],
            row_date = rec['ROW_CHANGED_DATE'],
            tie_in = rec[['N_OFFSET', 'E_OFFSET', 'TVD']].to_numpy(dtype=float),
            stations = survey[['MEASURED_DEPTH', 'INCLINATION', 'AZIMUTH']].to_numpy(dtype=float),
            max_inc = self.nlp_inc
        )
        return wb

class wellbore():
    def __init__(self, 
                 uwi, 
                 gov_id, 
                 elev, 
                 lat, 
                 lon, 
                 row_date, 
                 tie_in, 
                 stations, 
                 max_inc):

        self.uwi = uwi
        self.gov_id = gov_id
        self.elev = elev
        self.lat = lat
        self.lon = lon
        self.row_date = row_date
        self.tie_in = tie_in
        self.stations = stations
        self.max_inc = max_inc

        self.north = None
        self.east = None
        self.geog_epsg = None
        self.proj_epsg = None
        self.pos_log = None
        self.nlp = None
        self.nev_geog = None
        self.nev_cart = None
        self._work_survey()

    def _work_survey(self):
        if self.geog_epsg is None:
            self.geog_epsg = cvt.Datums(datum='nad27').epsg
        if self.proj_epsg is None:
            self.proj_epsg = cvt.api_num_2_epsg([self.gov_id], nad27=True).iloc[0]
        self.pos_log = position_log(self.stations, self.tie_in)
        self.nlp = hstats.horizontal_stats(self.stations, self.tie_in, max_inc=self.max_inc)
        true_north = True # because tdm surveys have been converted to true north
        self.nev_geog, self.nev_cart = cvt.forward_lat_lon(self.pos_log[:,3:6], 
                                                           self.lat, 
                                                           self.lon, 
                                                           self.geog_epsg, 
                                                           self.proj_epsg, 
                                                           true_north=true_north)

class work_uwi():
    def __init__(self, 
                 conn_str, 
                 well_dir_survey_station, 
                 wellbore, 
                 output_path=r'.\h_stats_csv_files', 
                 aggr_file=r'.\h_stats_pak.csv',
                 select_inc=70, 
                 nlp_inc=84):

        self.conn_str = conn_str
        self.well_dir_survey_station = well_dir_survey_station
        self.wellbore = wellbore
        self.output_path = output_path
        self.aggr_file = aggr_file
        self.select_inc = select_inc
        self.nlp_inc = nlp_inc
        
    def get_ekeys(self, all_ekeys=False):
        def gkeys():
            """
            Get all the eKeys from the database that have surveys with inclinations GT the set inclination theshhold.
            """
            db = Database(self.conn_str)
            return db.run(sql_statements(self.well_dir_survey_station, self.wellbore)['all_ekeys_sql'], params=[self.select_inc])
        def gcalced():
            """
            Get a dataframe that has all the results of runs we have made.
            """
            if not all_ekeys:
                return self.write_all(write=False)[['uwi', 'mod_date']]
            else:
                return None
        def fetch_dat(op):
            if op == 'ekeys':
                return gkeys()
            else:
                return gcalced()
        
        ops = ['ekeys', 'calced']
        with tqdm_joblib(tqdm(desc="Getting ekeys...", total=len(ops))) as progress_bar: # pylint: disable=unused-variable
            dfs = Parallel(n_jobs=2)(delayed(fetch_dat)(ops[i]) for i in range(len(ops)))
        
        ekeys_df = dfs[0]
        calced_df = dfs[1]
        
        if all_ekeys:
                return ekeys_df['EKEY_WELLBORE'].to_list()
        
        # left join the full list of eKeys with the list of results we have calc'ed so far
        test_df = ekeys_df.merge(calced_df, left_on='EKEY_WELLBORE', right_on='uwi', how='left')
        min_date = test_df['ROW_CHANGED_DATE'].min() # get the earliest change date that is in the TDM database for the selected set of wellbores
        # if we have new wellbores in our TDM list of eKeys, then they well not have been calc'ed and thus not in our calc'ed list
        test_df.loc[pd.isnull(test_df['mod_date']), 'mod_date'] = min_date # assign the minimum date to the un-calc'ed eKeys
        # if there has been a change in the TDM data or the eKey was never calc'ed (we set it in the line above)
        # then the data change in the database will be GT that of the calc'ed eKey 
        # so we return those that need re=calc'ed
        return test_df[test_df['mod_date'] <= test_df['ROW_CHANGED_DATE']]['EKEY_WELLBORE'].to_list()
    
    def get_data(self, sql, prm):
        db = Database(self.conn_str)
        return db.run(sql, params=prm)
    
    def work_one(self, ekey, write_results=True):
        sql = sql_statements(self.well_dir_survey_station, self.wellbore, self.select_inc, ekey)
        # ops = ['one_survey_sql', 'one_tie_in_sql_x']
        # prm = [[ekey], []]
        # with tqdm_joblib(tqdm(desc="Getting Data...", total=len(ops))) as progress_bar:
        #     dfs = Parallel(n_jobs=2)(delayed(self.get_data)(sql[ops[i]], prm[i]) for i in range(len(ops)))
        
        db = Database(self.conn_str)
        survey = db.run(sql['one_survey_sql_x']) #db.run(sql['one_survey_sql'], params=[ekey])
        header = db.run(sql['one_tie_in_sql_x']) #db.run(sql['one_tie_in_sql'], params=[ekey])
        
        rec = header.iloc[0]
        uwi = ekey #rec['EKEY_WELLBORE']
        gov_id = rec['GOVERNMENT_ID']
        elev = rec['DEPTH_DATUM_ELEV']
        lat = rec['LATITUDE']
        lon = rec['LONGITUDE']
        tie_in = rec[['N_OFFSET', 'E_OFFSET', 'TVD']].to_numpy(dtype=float)
        #row_date = rec['ROW_CHANGED_DATE']
        srv = survey[['MEASURED_DEPTH', 'INCLINATION', 'AZIMUTH']].to_numpy(dtype=float)
        
        stats, error = calc_h_stats(srv, tie_in, lat, lon, hstats.horizontal_stats_meta()['names'], max_inc=self.nlp_inc)
        hstats_df = pd.DataFrame([stats], columns=hstats.horizontal_stats_meta()['names'])
        one_stat = hstats_df.iloc[0]
        calc_meta(one_stat, uwi, gov_id, elev, error, datetime.datetime.now())
        calc_mid(one_stat)
        calc_lat_lon(one_stat, gov_id, elev, lat, lon)
        df = pd.DataFrame([one_stat])[full_stats_meta()]
        if write_results:
            df.to_csv(self.make_up_file_path(ekey), index=False)
            return
        else:
            return df
    
    def make_up_file_path(self, ekey):
        return os.path.join(self.output_path, f'h_stat_{ekey}.csv')
    
    def work_many(self, ekeys):
        with tqdm_joblib(tqdm(desc="Working ekeys...", total=len(ekeys))) as progress_bar: # pylint: disable=unused-variable
            Parallel(pre_dispatch='2*n_jobs', n_jobs=JOBS)(delayed(self.work_one)(ekeys[i]) for i in range(len(ekeys)))
        
    def write_all(self, write=True):
        # get the list of all results that have been calc'ed.  The results for each wellbore are stored in a csv file
        csvs = glob.glob(fr'{self.output_path}\*.csv')
        with tqdm_joblib(tqdm(desc="Working csv files...", total=len(csvs))) as progress_bar: # pylint: disable=unused-variable
            # read each csv file into a dataframe
            dfs = Parallel(pre_dispatch='2*n_jobs', n_jobs=JOBS)(delayed(pd.read_csv)(csvs[i], index_col=False, parse_dates=['mod_date']) for i in range(len(csvs)))
        
        df = None
        try:
            df = pd.concat(dfs) # concatenate the individual dataframes into a single dataframe
        except:
            df = pd.DataFrame({'uwi' : [], 'mod_date': []}) # just create a blank dataframe because we have noting to concat
            #pass # because we have noting to concat
        
        if write:
            # write our results to a file
            df.to_csv(self.aggr_file, index=False)
        
        return df

def main(all_ekeys=False):
    """
    TDM1.0 - SQLTD01-MID-PRD\MSSQLTDMPRD
    TDM2.0 - SQLTDM1-MID-PRD
    """
    warnings.filterwarnings("ignore", category=RuntimeWarning) 

    well_dir_survey_station = 'COG_GIS_WELL_DIR_SURVEY_STATION_OVW'
    wellbore = 'COG_GIS_WELLBORE_OVW' #'COG_GIS_WELLBORE_PERMIAN_OVW'
    conn_str = ('Driver={ODBC Driver 17 for SQL Server};'
                'Server={SQLTD01-MID-PRD\MSSQLTDMPRD};'
                'Port={1433};'
                'Database={PPDM38};'
                f'UID={env("TDM:USER")};' 
                f'PWD={env("TDM:PASSWORD")};')
    output_path = r'C:\Users\dbaker\OneDrive - ConocoPhillips\Home\My Programs\python\azure_devops\tdm_h-stats\h_stats_csv_files'
    select_inc = 70
    nlp_inc = 80

    wu = work_uwi(conn_str, well_dir_survey_station, wellbore, output_path=output_path, select_inc=select_inc, nlp_inc= nlp_inc)

    if DEBUG:
        #ekeys = ['10463395-003', '10127638-001', '10848973-005', '10893052-003']
        ekeys = ['14588276-001', '14469708-001', '10912792-001', '11054170-007','14519741-001', '10463395-003', '10127638-001', '10848973-005', '10893052-003']  #['14519741-001']
        # ekey = '10127344-003' #ekeys[0] 10192329-007 = no header
        # ekey = ekeys[0]
        # print(ekey) # 2242/34961
        # 2826 rows × 47 columns%%time

        # ekey = '10463395-003' # this ekey cause an inslerpolate error
        # ekey = '10127638-001' # this ekey has duped mds
        # df = wu.work_one(ekey, write_results=not DEBUG)
        # print(df)
        wu.work_many(ekeys)
    else:
        ekeys = wu.get_ekeys(all_ekeys=all_ekeys)
        wu.work_many(ekeys)
        full_stats = wu.write_all()
        print(len(full_stats))

if __name__ == "__main__":
    '''
    Passing a paramenter will force working all ekeys
    even if worked before.  Use this option to redo all
    wellbores.
    '''
    all_ekeys = len(sys.argv) > 1
    main(all_ekeys)