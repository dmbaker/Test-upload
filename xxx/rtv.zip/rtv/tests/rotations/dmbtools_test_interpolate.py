import numpy as np
from dmbtools.wellbore import survey as srvy

np.set_printoptions(formatter={'float': lambda x: "{0:0.3f}".format(x)})

st_srv, st_tie_in = srvy.S_and_T_survey()

step = 10

st_interp_new = srvy.inslerpolate_new(st_srv, st_tie_in, step=step)

#st_interp_org = srvy.inslerpolate(st_srv, st_tie_in, step=st_srv[:,0])
st_interp_org = srvy.inslerpolate(st_srv, st_tie_in, step=step)
