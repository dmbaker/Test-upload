import numpy as np

def modulus(theta, modby):
    """
    Calculate the positive cyclic modulus of theta by modby.
    """
    is_scalar = np.ndim(theta) == 0
    theta = np.atleast_1d(theta)
    
    k = (theta / modby).astype(int)
    theta -= k * modby
    theta[theta < 0.0] += modby
    return theta[0] if is_scalar else theta

def quantize_dmb(x, fraction=0.5):
    """
    Round a number, or list of numbers, to the closest fraction.
    >>> quantize(1.3, fraction=0.5)
    1.5
    >>> quantize(2.6, fraction=0.5)
    2.5
    >>> quantize(3.0, fraction=0.5)
    3.0
    >>> quantize(4.1, fraction=0.5)
    4.0
    >>> quantize([1.3, 2.6, 3.0 ,4.1], fraction=0.5)
    [1.5, 2.5, 3.0, 4.0]
    """
    
    is_scalar = np.ndim(x) == 0
    x = np.atleast_1d(x)
    
    div = 1.0 / fraction
    qnt = np.round(x * div) / div
    return qnt[0] if is_scalar else qnt

def quantize(x, fraction=0.5):
    """
    Round a number, or list of numbers, to the closest fraction.
    >>> quantize(1.3, fraction=0.5)
    1.5
    >>> quantize(2.6, fraction=0.5)
    2.5
    >>> quantize(3.0, fraction=0.5)
    3.0
    >>> quantize(4.1, fraction=0.5)
    4.0
    >>> quantize([1.3, 2.6, 3.0 ,4.1], fraction=0.5)
    [1.5, 2.5, 3.0, 4.0]
    """
    
    is_scalar = np.ndim(x) == 0
    x = np.atleast_1d(x)
    
    div = 1.0 / fraction
    qnt = np.round(x * div) / div
    return qnt[0] if is_scalar else qnt

def normalized(a, axis=-1, order=2):
    """
    Normalize a vector for arbitrary axes, and giving optimal performance.
    """
    one_dim = np.ndim(a) == 0 or np.ndim(a) == 1
    l2 = np.atleast_1d(np.linalg.norm(a, order, axis))
    l2[l2==0] = 1
    ret = a / np.expand_dims(l2, axis)
    return ret[0] if one_dim else ret

def norm_vectors(vectors):
    """
    https://stackoverflow.com/questions/2850743/numpy-how-to-quickly-normalize-many-vectors
    """
    just_one = np.ndim(vectors) == 1
    #a = np.atleast_2d(vectors)
    
    vectors = np.atleast_2d(vectors)
    ret = vectors / np.sqrt(np.einsum('...i,...i', vectors, vectors))[:,None]
    return ret[0] if just_one else ret

def einsumdot(x, y):
    """
    Rowwise dot product
    """
    return np.einsum('ij,ij->i', x, y)