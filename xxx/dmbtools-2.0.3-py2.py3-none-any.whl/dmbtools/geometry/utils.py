import numpy as np

def reflect(u, v):
    """
    Returns the vector v reflected in the unit vector u.
    """
    return 2.0 * np.dot(v, u) * u - v

def angle(u, v):
    """
    Returns the unoriented angle between two non-singular unit length vectors.
    """
    dims = np.ndim(u)
    is_1d = dims == 1
    u = np.atleast_2d(u)
    v = np.atleast_2d(v)
    ang = 2.0 * np.arctan(np.linalg.norm(v - u, axis=1) / np.linalg.norm(u + v, axis=1))
    return ang[0] if is_1d else ang

def toUnitDir(degINC, degAZ):
    """
    Convert spherical coordinates to cubic coordinates (NEV), a unit length direction vector
    in a right handed coordinate system.
    """
    dim_inc = np.ndim(degINC)
    is_scalar = dim_inc == 0
    degINC = np.atleast_1d(degINC)
    degAZ = np.atleast_1d(degAZ)
    
    inc = np.deg2rad(degINC)
    az = np.deg2rad(degAZ)
    deltaN = np.sin(inc) * np.cos(az)
    deltaE = np.sin(inc) * np.sin(az)
    deltaV = np.cos(inc)

    nev = np.column_stack((deltaN, deltaE, deltaV))
    return nev[0] if is_scalar else nev

def toSpherical(unit_t):
    """
    Convert a unit direction vector in NEV coordinates to a tuple of Inclination and Azimuth.
    """
    is_1d = np.ndim(unit_t) == 1
    unit_t = np.atleast_2d(unit_t)
    
    inc = np.arctan2(np.sqrt(unit_t[:,0] * unit_t[:,0] + unit_t[:,1] * unit_t[:,1]), unit_t[:,2])
    az = np.arctan2(unit_t[:,1], unit_t[:,0])
    # return a result for az such that az is [0.0, 360.0)
    az[az < 0.0] += 2.0 * np.pi
    # for very small, negative angles, angle + 2pi = 2pi, which is outside the
    # output domain [0, 360). So add 2*pi again.
    # per: https://stackoverflow.com/questions/37358016/numpy-converting-range-of-angles-from-pi-pi-to-0-2pi
    az[az < 0.0] += 2.0 * np.pi
    ia = np.column_stack((np.rad2deg(inc), np.rad2deg(az)))
    return ia[0] if is_1d else ia

def slerp(t, u, v, theta=None):
    """
    https://www.plunk.org/~hatch/rightway.php
    Spherical linear interpolation.
    Returns a unit vector a fraction, t, between unit vectors u and v.
    t: a float or an array of floats to interpolate.
    u and v: are unit vectors.
    theta: the angle between u and v. If none then the angle is calculated.
    """
    def _sin_over_x(x):
        """
        Numerically stable sin_over_x function.
        """
        mask = 1.0 + (x * x) == 1.0
        x[mask] = 1.0
        x[~mask] = np.sin(x[~mask]) / x[~mask]
        return x
    
    is_scalar = np.ndim(t) == 0
    t = np.atleast_1d(t)[:,None]
    if theta is None:
        theta = 2.0 * np.arctan(np.linalg.norm(v - u) / np.linalg.norm(u + v))
    
    q = 1.0 - t
    d = _sin_over_x(np.atleast_1d(theta))[0]
    l = (_sin_over_x(q * theta) / d) * (q * u)
    r = (_sin_over_x(t * theta) / d) * (t * v)
    w = l + r
    
    return w[0] if is_scalar else w

def slerp2(t, u, v, theta=None):
    """
    https://www.plunk.org/~hatch/rightway.php
    Spherical linear interpolation.
    Returns a unit vector a fraction, t, between unit vectors u and v.
    t: an array of floats to interpolate.
    u: an array of unit direction vectors at the begining of the arc.
    v: an array of unit direction vectors at the end of the arc.
    theta: the angle between u and v. If none then the angle is calculated.
    """
    def _sin_over_x(x):
        """
        Numerically stable sin_over_x function.
        """
        x = x.copy()
        mask = 1.0 + (x * x) == 1.0
        x[mask] = 1.0
        x[~mask] = np.sin(x[~mask]) / x[~mask]
        return x
    
    if theta is None:
        theta = angle(u, v) #2.0 * np.arctan(np.linalg.norm(v - u) / np.linalg.norm(u + v))
    
    # q = 1.0 - t
    # d = _sin_over_x(np.atleast_1d(theta))
    # l = (_sin_over_x(q * theta) / d) * (q * u)
    # r = (_sin_over_x(t * theta) / d) * (t * v)
    # w = l + r
    
    q = 1.0 - t
    d = _sin_over_x(np.atleast_1d(theta))
    l = ((_sin_over_x(q * theta) / d)[:,None]) * (q[:,None] * u)
    r = ((_sin_over_x(t * theta) / d)[:,None]) * (t[:,None] * v)
    w = l + r
    
    return w

def rtv_org(ui, uf, a):
    """
    http://xahlee.info/math/i/transvection_for_rotations.pdf
    Rotate vectors via transvection.
    Rotates a vector, a, in the frame from ui to uf.
    ui and uf are assumed to be unit vectors.
    Assume a, ui and uf are numpy (1,3) arrays.
    """
    s = ui + uf
    c = 2.0 / np.dot(s, s)
    w = (2.0 * np.dot(a, ui)) * ui - a
    r = (c * np.dot(w, s)) * s - w
    
    return r

def rtv(ui, uf, a):
    """
    http://xahlee.info/math/i/transvection_for_rotations.pdf
    Rotate vectors via transvection.
    Rotates an array of vectors, a, in the frame from ui to uf.
    ui and uf are assumed to be unit vectors.
    Assume ui and uf are numpy (1,3) arrays and a is
    numpy (N,3) array.
    """
    just_one = np.ndim(a) == 1
    a = np.atleast_2d(a)
    
    s = ui + uf
    c = 2.0 / np.dot(s, s)
    w = (2.0 * np.dot(a, ui))[:,None] * ui - a
    r = (c * np.dot(w, s))[:,None] * s - w
    
    return r[0] if just_one else r

def rtv_einsum(ui, uf, a):
    """
    http://xahlee.info/math/i/transvection_for_rotations.pdf
    Rotate vectors via transvection.
    Rotates the row vectors, a, in the frame of each row in ui to uf
    from ui to uf.  The row vectors in ui and uf are assumed to be
    unit length. This method uses einsum to calculate the rowwise
    dot product.
    
    Parameters
    ----------
    a : 2-D array_like
        An (N, M) 2-D array.
    ui, uf : 2-D array_like
        An (N, M) 2-D array where each row vector is unit length
        in an M-dimensional space
    
    Returns
    -------
    a-rotated : 2-D array_like
        An (N, M) 2-D array where each row vector in a is rotated
        from the matching row vector in ui to the matching row vector in uf
    
    Examples
    --------
    >>> ui = np.array([[1, 0, 0, 0, 0],[0, 0, 0, 0, 1]])
    >>> uf = np.array([[0, 1, 0, 0, 0],[0, 0, 0, 1, 0]])
    >>> aa = np.array([[1, 1, 0, 0, 0],[0, 0, 0, 1, 1]])
    
    >>> rtv_einsum(ai, uf, aa)
    array([[-1.,  1.,  0.,  0.,  0.], [ 0.,  0.,  0.,  1., -1.]])
    
    """
    just_one = np.ndim(a) == 1
    a = np.atleast_2d(a)
    
    s = ui + uf
    c = (2.0 / np.einsum('ij,ij->i', s,  s))
    w = (2.0 * np.einsum('ij,ij->i', a, ui))[:,None] * ui - a
    r = (c   * np.einsum('ij,ij->i', w,  s))[:,None] *  s - w
 
    return r[0] if just_one else r

def rodrigues(theta, n, v):
    """
    Rodrigues rotation formula.
    Rotate vector v around vector n by theta.
    https://en.wikipedia.org/wiki/Rodrigues%27_rotation_formula
    """
    just_one = np.ndim(v) == 1
    v = np.atleast_2d(v)
    r = v * np.cos(theta) + np.cross(n, v) * np.sin(theta) + n * n.dot(v.T)[:,None] * (1.0 - np.cos(theta))
    return r[0] if just_one else r

def gibbs(theta, n, v):
    """
    Gibbs rotation formula.
    Rotate vector v around vector n by theta.
    https://arxiv.org/ftp/arxiv/papers/1607/1607.05999.pdf
    """
    just_one = np.ndim(v) == 1
    v = np.atleast_2d(v)
    I  = np.array([[1.0, 0.0, 0.0],
                   [0.0, 1.0, 0.0],
                   [0.0, 0.0, 1.0]])
    Q  = np.tan(theta / 2.0) * n # a 3D vector
    Qx = _pee_cross(Q)
    t1 = 2.0 / (1.0 + Q.dot(Q)) # scalar
    t2 = Qx + (Qx @ Qx) # matrix
    RQ = I + t1 * t2
    r = (RQ @ v.T).T
    return r[0] if just_one else r

def _pee_crossOld(p):
        """
        http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
        p: a column vector.
        """
        return np.matrix([[0.0, -p[2], p[1]], [p[2], 0.0, -p[0]], [-p[1], p[0], 0.0]])

def _pee_cross(p):
        """
        http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
        p: a column vector.
        """
        return np.array([[0.0, -p[2], p[1]], [p[2], 0.0, -p[0]], [-p[1], p[0], 0.0]])

def closest_point(u, v, y):
    """
    Calculate the closet point on a line.
    http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
    Paragraph 9: Applications of Cross-Products to Geometrical Problems, #6
    using and assuming conditions for the 1st equation, that is,
    the distance between z and y is much less than the distance to y.
    u = 3D point on the line
    v = unit direction vector of the line, w - u, in the paper
    y = an array of points to test
    """
    just_one = np.ndim(y) == 1
    y = np.atleast_2d(y)
    vc = _pee_cross(v)
    #z = y + vc.dot(vc).dot((y - u).T).T # / v.dot(v) because v in length of 1.0
    z = (y.T + (vc @ vc) @ (y - u).T).T
    return z[0] if just_one else z

def closest_point2(u, v, y):
    """
    Calculate the closet point on a line.
    http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
    Paragraph 9: Applications of Cross-Products to Geometrical Problems, #6
    using and assuming conditions for the 2nd equation, that is,
    the distance between z is much less than to u.
    u = 3D point on the line
    v = unit direction vector of the line, w - u, in the paper
    y = an array of points to test
    """
    just_one = np.ndim(y) == 1
    y = np.atleast_2d(y)
    vc = _pee_cross(v)
    # z = y - vc.dot(vc).dot(u.T).T # / v.dot(v) because v in length of 1.0
    z = (np.outer(v, v.T) @ y.T).T -((vc @ vc) @ u)
    return z[0] if just_one else z

def closest_point3(u, v, y):
    """
    Calculate the closet point on a line.
    http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
    Paragraph 9: Applications of Cross-Products to Geometrical Problems, #6
    using and assuming conditions for the 3rd equation, that is,
    the distance between z is much less than to y.
    u = 3D point on the line
    v = unit direction vector of the line, w - u, in the paper
    y = an array of points to test
    """
    just_one = np.ndim(y) == 1
    y = np.atleast_2d(y)
    #vc = _pee_cross(v)
    #z = u + v.dot(v.T).T * (y - u) # z = u + (v * v.T) * (y - u)
    z = u + (np.outer(v, v.T) @ (y - u).T).T
    return z[0] if just_one else z

def closest_point_plane(x, p, y):
    """
    Calculate the closet point on a line.
    http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
    Paragraph 9: Applications of Cross-Products to Geometrical Problems, #1
    using and assuming conditions for the 1st equation, that is,
    the distance between z and y is much less than the distance to y.
    x = 3D point on the plane
    p = unit vector normal to the plane
    y = a point or an array of points to test
    """
    just_one = np.ndim(y) == 1
    y = np.atleast_2d(y)
    pi = p.dot(x)
    z = y - p * (p.dot(y.T) - pi)[:,None] # / p.dot(p) because p is a unit length vector
    return z[0] if just_one else z

def closest_point_plane2(x, p, y):
    """
    Calculate the closet point on a line.
    http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
    Paragraph 9: Applications of Cross-Products to Geometrical Problems, #1
    using and assuming conditions for the 2nd equation, that is,
    the distance between z is much less than to y.
    x = 3D point on the plane
    p = unit vector normal to the plane
    y = a point or an array of points to test
    """
    just_one = np.ndim(y) == 1
    y = np.atleast_2d(y)
    pc = _pee_cross(p)
    pi = p.dot(x)
    z = p * pi - ((pc @ pc).dot(y.T)).T # / p.dot(p) because p is a unit length vector
    return z[0] if just_one else z