def test():
    print("testing 1,2,3,4...")
    return "testing 1,2,3,4..."