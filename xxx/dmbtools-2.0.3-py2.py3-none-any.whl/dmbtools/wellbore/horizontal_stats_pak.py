import numpy as np
from collections import OrderedDict

from ..math.utils import normalized
from ..geometry.utils import rtv, closest_point, toSpherical
from ..wellbore.normalized_landing_point import nlp
from ..wellbore.survey import inslerpolate

class HStatsError(Exception):
    pass

def test_crow_length(pos_log, method):
    crow_len = np.linalg.norm(pos_log[-1] - pos_log[0])
    if (1.0 + crow_len) == 1.0:
        raise HStatsError(f'The {method} mean lateral path length is zero.')
    return crow_len

def tortuosity(pos_log, lat_len):
    path_len = lat_len
    crow_len = test_crow_length(pos_log, 'tortuosity')
    return path_len / crow_len

def sinuosity(pos_log):
    pos_log = pos_log.copy()
    pos_log[:,2] = 0.0 # project into the horizontal plane
    path_len = np.linalg.norm(pos_log[1:] - pos_log[:-1], axis=1).sum() # distance along the path
    crow_len = test_crow_length(pos_log, 'sinuosity') # distance as the crow flies
    return path_len / crow_len

def undulation(pos_log, bfit_dir):
    pos_log = pos_log.copy()
    bfit_dir = bfit_dir.copy()
    bfit_dir[2] = 0.0 # project to the horizontal plane
    bfit_dir = normalized(bfit_dir)
    pos_log = rtv(bfit_dir, np.array([1.0, 0, 0]), pos_log) # rotate to north
    pos_log[:,1] = 0.0 # project onto the azimuthal plane
    path_len = np.linalg.norm(pos_log[1:] - pos_log[:-1], axis=1).sum()
    crow_len = test_crow_length(pos_log, 'undulation')
    return path_len / crow_len

def horizontal_stats(survey, tie_in, offset=None, nominal_step=5.0, min_inc=40.0, max_inc=80.0, critical_k=1.0/15000.0, discretize_step=1.0, mean_div=3):
    """
    The Horizontal Stats Pak...
    """
    
    # calc the normalized landing point measured depth
    nlp_md = nlp(survey, tie_in, nominal_step=nominal_step, min_inc=min_inc, max_inc=max_inc, critical_k=critical_k, mean_div=mean_div) 
    nlp_sta = np.array(inslerpolate(survey, tie_in, step=[nlp_md])) # interpolate a survey station at the nlp_md
    lateral_mask = survey[:,0] > nlp_md # all surveys after the nlp
    lateral_srv = np.concatenate([nlp_sta[:,0:3], survey[lateral_mask]], axis=0) # prepend the nlp station
    lat_srv_interp = inslerpolate(lateral_srv, nlp_sta[0,3:6], step=discretize_step) # do a fine grained interpolation
    lat_srv_pos = lat_srv_interp[:,3:6] # interpolated points of the lateral
    heel_toe = np.array([lat_srv_pos[0,:], lat_srv_pos[-1,:]])
    
    datamean = lat_srv_pos.mean(axis=0) # Calculate the mean of the points, i.e. the 'center of mass' of the point cloud
    uu, dd, vv = np.linalg.svd(lat_srv_pos - datamean) # Do an SVD on the mean-centered data.
    # Now vv[0] contains the first principal component, i.e. the direction
    # vector of the 'best fit' line in the least squares sense.
    
    # the end points of the best fit line defined by the orthogonal projections of the heal and toe of the lateral onto the line
    end_pts = closest_point(datamean, vv[0], [lat_srv_pos[0], lat_srv_pos[-1]])
    
    # the stats
    lateral_length = lateral_srv[-1,0] - lateral_srv[0,0] # difference in md's between the heal and toe of the lateral
    best_fit_segment = end_pts[-1] - end_pts[0] # the line segment of the best line between the projected heal and toe of the lateral
    best_fit_direction = normalized(best_fit_segment) # direction of the best fit line from heal/nlp to toe/TD
    mean_length = np.linalg.norm(best_fit_segment) # the length of the best fit line segment
    mean_inc, mean_az = toSpherical(best_fit_direction) # the inc and az of the best fit line
    toru = tortuosity(lat_srv_pos, lateral_length)
    sinu = sinuosity(lat_srv_pos)
    undu = undulation(lat_srv_pos, best_fit_direction)
    
    if offset is not None:
        end_pts += offset
    
    stats = [nlp_md],
    stats = np.append(stats, np.array(heel_toe))
    stats = np.append(stats, np.array(end_pts))
    stats = np.append(stats, best_fit_direction)
    stats = np.append(stats, [mean_inc, mean_az, mean_length])
    stats = np.append(stats, [lateral_length, toru])
    stats = np.append(stats, [sinu, undu])
    return stats

def h_stats(uwi, survey, tie_in, offset=None, nominal_step=5.0, min_inc=40.0, max_inc=80.0, critical_k=1.0/15000.0, discretize_step=1.0, mean_div=3):
    """
    The Horizontal Stats Pak...
    """
    
    # calc the normalized landing point measured depth
    nlp_md = nlp(survey, tie_in, nominal_step=nominal_step, min_inc=min_inc, max_inc=max_inc, critical_k=critical_k, mean_div=mean_div) 
    nlp_sta = np.array(inslerpolate(survey, tie_in, step=[nlp_md])) # interpolate a survey station the the nlp_md
    lateral_mask = survey[:,0] > nlp_md # all surveys after the nlp
    lateral_srv = np.concatenate([nlp_sta[:,0:3], survey[lateral_mask]], axis=0) # prepend the nlp station
    lat_srv_interp = inslerpolate(lateral_srv, nlp_sta[0,3:6], step=discretize_step) # do a fine grained interpolation
    lat_srv_pos = lat_srv_interp[:,3:6] # interpolated points of the lateral
    heel_toe = np.array([lat_srv_pos[0,:], lat_srv_pos[-1,:]])
    
    datamean = lat_srv_pos.mean(axis=0) # Calculate the mean of the points, i.e. the 'center of mass' of the point cloud
    uu, dd, vv = np.linalg.svd(lat_srv_pos - datamean) # Do an SVD on the mean-centered data.
    # Now vv[0] contains the first principal component, i.e. the direction
    # vector of the 'best fit' line in the least squares sense.
    
    # the end points of the best fit line defined by the orthogonal projections of the heal and toe of the lateral onto the line
    end_pts = closest_point(datamean, vv[0], [lat_srv_pos[0], lat_srv_pos[-1]])
    
    # the stats
    lateral_length = lateral_srv[-1,0] - lateral_srv[0,0] # difference in md's between the heal and toe of the lateral
    best_fit_segment = end_pts[-1] - end_pts[0] # the line segment of the best line between the projected heal and toe of the lateral
    best_fit_direction = normalized(best_fit_segment) # direction of the best fit line from heal/nlp to toe/TD
    mean_length = np.linalg.norm(best_fit_segment) # the length of the best fit line segment
    mean_inc, mean_az = toSpherical(best_fit_direction) # the inc and az of the best fit line
    toru = tortuosity(lat_srv_pos, lateral_length)
    sinu = sinuosity(lat_srv_pos)
    undu = undulation(lat_srv_pos, best_fit_direction)
    
    if offset is not None:
        end_pts += offset
    
    stats = [uwi, nlp_md],
    stats = np.append(stats, np.array(heel_toe))
    stats = np.append(stats, np.array(end_pts))
    stats = np.append(stats, best_fit_direction)
    stats = np.append(stats, [mean_inc, mean_az, mean_length])
    stats = np.append(stats, [lateral_length, toru])
    stats = np.append(stats, [sinu, undu])
    return stats

def h_stats_meta():
    """
    returns a list of the names of the columns in the h_stats pak
    and an empty record. Can be used to build a dataframe for the
    stats pak.
    """
    h_stats_names = [
        'uwi', 
        'nlp_md', 
        'nlp_n', 'nlp_e', 'nlp_v', 
        'td_n', 'td_e', 'td_v', 
        'mean_bgn_n', 'mean_bgn_e', 'mean_bgn_v', 
        'mean_end_n', 'mean_end_e', 'mean_end_v', 
        'mean_dir_n', 'mean_dir_e', 'mean_dir_v', 
        'mean_inc', 
        'mean_azi', 
        'mean_len', 
        'lateral_len', 
        'tortuosity', 
        'sinuosity', 
        'undulation']

    empty_h_stats_rec = [
        '',
        np.nan,
        np.nan, np.nan, np.nan,
        np.nan, np.nan, np.nan,
        np.nan, np.nan, np.nan,
        np.nan, np.nan, np.nan,
        np.nan, np.nan, np.nan,
        np.nan,
        np.nan,
        np.nan,
        np.nan,
        np.nan,
        np.nan,
        np.nan
    ]

    return {'names': h_stats_names, 'empty_rec': empty_h_stats_rec}

def horizontal_stats_meta():
    ## h_stats_names, empty_h_stats_rec = h_stats_meta()
    return {'names': h_stats_meta()['names'][1:], 'empty_rec': h_stats_meta()['empty_rec'][1:]}
