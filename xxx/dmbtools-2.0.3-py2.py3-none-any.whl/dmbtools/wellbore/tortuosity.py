import numpy as np
from ..geometry import utils as gu
from ..wellbore import survey as srv

class TortuosityError(Exception):
    pass

class TortuosityWarning(UserWarning):
    pass

class Tortuosity():
    """
    Class to calculate wellbore tortuosity from a deviation survey.
    Returns various measures.
    survey: a list deviation surveys. [[md_0, inc_0, azi_0], [md_1, inc_1, azi_1],...]

    """
    def __init__(self, survey, dog_leg_course_length=100, normalising_curvature=90):
        self.survey = survey
        self.dog_leg_course_length = dog_leg_course_length
        self.normalising_curvature = normalising_curvature
    
    def _diff_col(self, col):
        """
        Return a 1D array that is the same length as col that is the
        difference between consecutive elements in col.  The first
        element in the returned array will be zero.
        """
        col = np.atleast_1d(col)
        x = np.zeros(col.shape[0])
        x[1:] = col[1:] - col[:-1]
        return x

    def _sum_col(self, col):
        """
        Return a 1D array that is the same length as col that is the
        sum between consecutive elements in col.  The first
        element in the returned array will be zero.
        """
        col = np.atleast_1d(col)
        x = np.zeros(col.shape[0])
        x[1:] = col[1:] + col[:-1]
        return x

    def _delta_md(self, md):
        return self._diff_col(md)
    
    def _delta_inc(self, inc_deg):
        return self._diff_col(inc_deg)
    
    def _delta_az(self, inc_deg):
        """
        IF(ABS(D6-D5)>180,(D6-D5)-360*SIGN(D6-D5),D6-D5))
        """
        diff = self._diff_col(inc_deg)
        mask = np.abs(diff) > 180.0
        diff[mask] -= 360.0 * np.sign(diff[mask])
        return diff

    def _build_rate(self, d_inc, d_md):
        """
        IF(AU$3=2,IF(G6>0,30*F6/G6,0),IF(G6>0,100*F6/G6,0)))
        """
        res = np.zeros(d_md.shape[0])
        mask = d_md > 0.0
        res[mask] = (self.dog_leg_course_length * d_inc[mask] / d_md[mask])
        return res

    def _turn_rate(self, d_az, d_md):
        """
        IF(AU$3=2,IF(G6>0,30*E6/G6,0),IF(G6>0,100*E6/G6,0)))
        """
        res = np.zeros(d_md.shape[0])
        mask = d_md > 0.0
        res[mask] = (self.dog_leg_course_length * d_az[mask] / d_md[mask])
        return res

    def _effective_turn_rate(self, inc_deg, tr):
        """
        I6*SIN(0.5*(C6+C5)*0.0174533))
        This is lateral dogleg severity
        """
        res = tr * np.sin( 0.5 * self._sum_col(np.radians(inc_deg)))
        return res

    def _delta_br(self, br):
        return self._diff_col(br)

    def _delta_etr(self, etr):
        return self._diff_col(etr)

    def _unwanted_vertical_curvature(self, d_md, d_br):
        """
        M5+0.5*ABS(K6*G6/100)
        """
        res = 0.5 * np.abs(d_br * d_md / self.dog_leg_course_length)
        return np.cumsum(res)

    def _unwanted_lateral_curvature(self, d_md, d_etr,):
        """
        N5+0.5*ABS(L6*G6/100)
        """
        res = 0.5 * np.abs(d_etr * d_md / self.dog_leg_course_length)
        return np.cumsum(res)

    def _total_vertical_curvature(self, d_md, br):
        """
        O6+ABS(H7*G7)/100)
        """
        res = np.abs(d_md * br / self.dog_leg_course_length)
        return np.cumsum(res)

    def _total_lateral_curvature(self,d_md, etr):
        """
        X P5+ABS(E6*SIN(0.5*(C5+C6)*0.0174533))
        P6+ABS(J7*G7)/100)
        """
        res = np.abs(d_md * etr / self.dog_leg_course_length)
        return np.cumsum(res)

    def _vertical_tortuosity_index(self, uvc, tvc):
        """
        IF(ABS(O6-M6)>0.5,(M6/(O6-M6)),1)
        """
        res = np.ones(uvc.shape[0])
        diff = tvc - uvc
        mask = np.abs(diff) > 0.5
        res[mask] = uvc[mask] / diff[mask]
        return res

    def _lateral_tortuosity_index(self, ulc, tlc):
        """
        IF(ABS(P6-N6)>0.5,(N6/(P6-N6)),1)
        """
        res = np.ones(ulc.shape[0])
        diff = tlc - ulc
        mask = np.abs(diff) > 0.5
        res[mask] = ulc[mask] / diff[mask]
        return res

    def _dogleg_severity(self, br, etr):
        """
        SQRT(H6*H6+J6*J6)
        """
        return np.sqrt(br * br + etr * etr)

    def _dogleg_severity_difference(self, dls):
        """
        ABS(S6-S5)
        """
        return np.abs(self._diff_col(dls))

    def _cumulative_curvature(self,d_md, dls):
        """
        U5+S6*(B6-B5)/100)
        """
        return np.cumsum((dls * d_md) / self.dog_leg_course_length)

    def _unwanted_curvature(self, d_md, d_dls):
        """
        V5+T6*(B6-B5)*0.5/100)
        NOTE: this is UC in the plane of curvature, not vertical and lateral
        """
        return np.cumsum((d_dls * d_md * 0.5) / self.dog_leg_course_length)
    
    def _tortuosity_index_v1(self, vti, lti):
        """
        SQRT(Q6^2+R6^2)
        This is Angus' original formula
        """
        return np.sqrt(vti * vti + lti * lti)

    def _tortuosity_index_v2(self, tvc, tlc):
        """
        Per Angus' pptx CSPG talk 01-27-21
        """
        return np.sqrt(tvc * tvc + tlc * tlc) / self.normalising_curvature

    def _toolface_drilled(self, br, etr):
        """
        ATAN2(H7,J7+0.00001)/0.0174533)
        """
        return np.degrees(np.arctan2(etr, br))

    def spreadsheet(self):
        """
        Returns a 2D array of that mimics Angus' tortuosity spreadsheet.
        """
        md = self.survey[:,0]
        inc = self.survey[:,1]
        az = self.survey[:,2]
        d_md = self._delta_md(md)
        d_inc = self._delta_inc(inc)
        d_az = self._delta_az(az)
        br = self._build_rate(d_inc, d_md)
        tr = self._turn_rate(d_az, d_md)
        etr = self._effective_turn_rate(inc, tr)
        d_br = self._delta_br(br)
        d_etr = self._delta_br(etr)
        uvc = self._unwanted_vertical_curvature(d_md, d_br)
        ulc = self._unwanted_lateral_curvature(d_md, d_etr)
        tvc = self._total_vertical_curvature(d_md, br)
        tlc = self._total_lateral_curvature(d_md, etr)
        vti = self._vertical_tortuosity_index(uvc, tvc)
        lti = self._lateral_tortuosity_index(ulc, tlc)
        dls = self._dogleg_severity(br, etr)
        d_dls = self._dogleg_severity_difference(dls)
        tf_drld = self._toolface_drilled(br, etr)
        cum_crv = self._cumulative_curvature(d_md, dls)
        u_crv = self._unwanted_curvature(d_md, d_dls)
        ti_v1 = self._tortuosity_index_v1(vti, lti)
        ti_v2 = self._tortuosity_index_v2(tvc, tlc)

        cols = [md,
                inc,
                az,
                d_md,
                d_inc,
                d_az,
                br,
                tr,
                etr,
                uvc,
                ulc,
                tvc,
                tlc,
                vti,
                lti,
                dls,
                d_dls,
                tf_drld,
                cum_crv,
                u_crv,
                ti_v1,
                ti_v2]
        
        return np.column_stack(cols)
    
    def summary(self):
        """
        Returns a one line summary stats from Angus' spreadsheet.
        """
        last_row = self.spreadsheet()[-1,:]
        mnem = self.tortuosity_meta()[0]
        lu = dict(zip(mnem,range(len(mnem))))
        cols = ['cum_crv', 'u_crv', 'ti_v1', 'ti_v2']
        idx =[lu[col] for col in cols]
        return last_row[idx]

    def tortuosity_meta(self, summary=False):
        """
        Returns a tuple. The first element is list of the mnemonics for the columns in 
        the tortuosity spreadsheet.  The second is the long name for each column
        mnemonic.
        summary: bool, to return just the summary columns.
        """
        cols = ['md', 'measured_depth',
                'inc', 'inclination',
                'az', 'azimuth',
                'd_md', 'delta_measured_depth',
                'd_inc', 'delta_inclination',
                'd_az', 'delta_azimuth',
                'br', 'build_rate',
                'tr', 'turn_rate',
                'etr', 'effective_turn_rate',
                'uvc', 'unwanted_vertical_curvature',
                'ulc', 'unwanted_lateral_curvature',
                'tvc', 'total_vertical_curvature',
                'tlc', 'total_lateral_curvature',
                'vti', 'vertcal_tortuosity_index',
                'lti', 'lateral_tortuosity_index',
                'dls', 'dogleg_severity',
                'd_dls', 'delta_dogleg_severity',
                'tf_drld', 'tool_face_drilled',
                'cum_crv', 'cumulative_curvature',
                'u_crv', 'unwanted_curvature',
                'ti_v1', 'tortuosity_index_v1',
                'ti_v2', 'tortuosity_index_v2']
        
        cols = np.array(cols)
        summary_cols = cols[-4:]
        
        x = summary_cols if summary else cols
        return list(x[:,0]), list(x[:1])
