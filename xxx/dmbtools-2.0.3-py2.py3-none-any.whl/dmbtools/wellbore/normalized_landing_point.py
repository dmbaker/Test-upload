import numpy as np
from pandas.core.base import NoNewAttributesMixin

from ..math.utils import normalized
from ..geometry.utils import rtv, toUnitDir, toSpherical, angle
from ..wellbore.survey import position_log, inslerpolate

class NlpError(Exception):
    """
    Exception raised when there is an error in the nlp calculations.
    """
    pass

def _divide_survey(survey, nominal_step=None, metric=None):
    """
    Divide a deviation survey at the mid-points between survey stations
    up to a nominal step.
    survey: an array of [[MD, N, E, V], [MD, N, E, V],...].  N, E, V are
    tangent unit vectors at each MD index.
    nominal_step: float, the value to test against the metric calc'ed over the
    divided survey. If None then just divide the survey once and return.
    metric: callable, a callable called on the MD differences, the default is mean.
    The survey is continually divided until the metric over the differences is less than or 
    equal to the nominal_step.
    """
    def div(srv):
        srv_2 = np.empty((srv.shape[0]*2-1, srv.shape[1]))
        idx = np.arange(srv.shape[0])
        idx_2 = idx * 2
        idx_3 = (idx_2 - 1)[1:]
        mds = srv[:,0]
        mds_2 = mds[:-1] + ((mds[1:] - mds[:-1]) * 0.5)
        tgs = srv[:,1:]
        tgs_2 = normalized(tgs[:-1] + tgs[1:])
        srv_2[idx_2,0] = mds
        srv_2[idx_3,0] = mds_2
        srv_2[idx_2,1:] = tgs
        srv_2[idx_3,1:] = tgs_2
        return srv_2
    
    if nominal_step is None:
        return div(survey)

    if metric is None:
        metric = np.mean
    
    if metric(survey[1:,0]-survey[:-1,0]) <= nominal_step:
        return survey
    
    avg_step = nominal_step + 1
    while avg_step > nominal_step:
        survey = div(survey)
        avg_step = metric(survey[1:,0]-survey[:-1,0])
    
    return survey

def divide_survey(survey, nominal_step=None, metric=None):
    """
    Divide a deviation survey at the mid-points between survey stations
    up to a nominal step.
    survey: an array of [[MD, INC, AZ], [MD, INC, AZ],...]
    """
    srv = np.column_stack([survey[:,0], toUnitDir(survey[:,1], survey[:,2])])
    div = _divide_survey(srv, nominal_step=nominal_step, metric=metric)
    return np.column_stack([div[:,0], toSpherical(div[:,1:4])])

def _relative_vert_nlp_md(k, t):
    """
    Calculate the nlp from the point before the nlp by projecting arc to horizontal in the vertical plane.
    The relative md is the arc length from the last point to the nlp.
    k: scalar, average curvature
    t: 3D vector, the tangent at the point before the nlp.
    """
    half_alpha = np.pi / 2.0 - angle(t, np.array([0.0, 0.0, 1.0])) # half the total angle of the full arc.  Half way is the nlp
    return half_alpha / k # the delta md from the start point to the nlp

def _relative_3D_nlp_md(k, t0, t1):
    """
    Calculate the relative nlp md from the point before the nlp by projecting arc in the plane of the two tangents to horizontal.
    The relative md is the arc length from the last point to the nlp.
    k: scalar, average curvature to the arc to make.
    t0: 3D, NEV-vector, the tangent at the point just prior to t1.
    t1: 3D, NEV-vector, the tangent at the point just before the nlp.
    """
    vert = np.array([0.,0.,1.0])
    
    # first check for anti-parallel
    if (np.linalg.norm(t0 + t1) + 1.0) == 1.0: # we use the more conservative test because we will be taking a cross-product of these vectors
        raise NlpError('No solution, vectors are anti-parallel.')
    
    nlp_vert = _relative_vert_nlp_md(k, t1)
    # next check for straight hole
    if (((1.0 -  np.dot(t0, t1)) + 1.0) == 1.0): # again, use the more conservative test
        if (np.dot(t1, vert) + 1.0) == 1.0:
            return 0.0 # because we are so near horizontal already
        return nlp_vert, nlp_vert # be safe and just project in the vertical plane
    
    bn = normalized(np.cross(t0, t1)) # the bi-normal vector
    if ((1.0 - np.abs(np.dot(bn, vert))) + 1.0) == 1.0: # see if the vectors are anti-parallel
        raise NlpError('Solution is in the horizontal plane.')
    
    nr = normalized(np.cross(t1, bn)) # find the normal to the survey vector just before the nlp
    pr = normalized(np.array([bn[0], bn[1], 0.0])) # project bi-normal onto the horizontal plane
    rt = rtv(-vert, pr, bn) # rotate the bi-normal vector to point down the fall line of the arc plane; the normal to final horizontal vector
    alpha = angle(nr, rt) # the angle change from the last survey to horizontal
    
    return alpha / k, nlp_vert

def nlp(survey, tie_in, nominal_step=5.0, min_inc=40.0, max_inc=80.0, critical_k=1.0/15000.0, mean_div=3):
    """
    Calculate the normalized landing point md from a deviation survey.
    survey: a list of survey stations [(md, inc, az), (md, inc, az),...]
    tie_in: the coordinates of the first survey station.
    nominal_step: the average measured depth spacing between survey stations are successive division of the survey to that step. 
    min_inc: the inclination defining the start of the curve section.
    max_inc: the inclination defining the end of the curve section.
    critical_k: the curvature at or below which the wellbore section is considered straight.
    """
    div_srv = divide_survey(survey, nominal_step=nominal_step) # divide the survey to get enough data
    div_pos_log = position_log(div_srv, tie_in, report_raw=True) # calc the position log of the divided survey
    inc = div_srv[:,1] # the inclinations
    kkk = div_pos_log[:,-1] # the curvatures
    
    gteq_min_inc = (inc >= min_inc).cumsum() # the first non-zero is the first element gteq to our test inc
    if (gteq_min_inc == 0).all(): # test to see if we have any at all that are in our range. If all zero, then no element gteq the test inc
        raise NlpError('No surveys have an inclination GT min: ' + str(min_inc))
    gteq_min_inc[gteq_min_inc == 0] = gteq_min_inc[-1] + 1 # set zeros to something greater than the max. because cumsum, that last element is the max
    gteq_min_inc_idx = gteq_min_inc.argmin() # gives the index of the first element gteq to the test inc
    
    gteq_max_inc = (inc >= max_inc).cumsum() # the first non-zero is the first element gteq to our test inc
    if (gteq_max_inc == 0).all(): # test to see if we have any at all that are in our range. If all zero, then no element gteq the test inc
        raise NlpError('No surveys have an inclination GT max: ' + str(max_inc))
    gteq_max_inc[gteq_max_inc == 0] = gteq_max_inc[-1] + 1 # set zeros to something greater than the max. because cumsum, that last element is the max
    gteq_max_inc_idx = gteq_max_inc.argmin() # gives the index of the first element gteq to the test inc
    
    inc_mask = np.zeros(len(inc), dtype=bool)
    inc_mask[gteq_min_inc_idx:gteq_max_inc_idx+1] = True # mask of surveys in the curve in our inclination range
    
    kkk_mask = kkk > critical_k # non straight hole curvatures
    
    inc_kkk_mask = inc_mask & kkk_mask
    if inc_kkk_mask.sum() == 0:
        raise NlpError('No surveys found in the critical inclination range that are also not straight hole.')
    
    k_mean = np.sort(kkk[inc_kkk_mask])[-mean_div:].mean() # we don't want any tangent sections in the mean curvature calc
    t0, t1 = div_pos_log[gteq_max_inc_idx-1,1:4], div_pos_log[gteq_max_inc_idx,1:4]
    nlp_md_3D, nlp_md_vert = _relative_3D_nlp_md(k_mean, t0, t1)
    t1_md = div_pos_log[gteq_max_inc_idx, 0]
    
    nlp_md_3D += t1_md
    nlp_3D_x = np.array(inslerpolate(survey, tie_in, step=[nlp_md_3D])) #[0]
    nlp_3D = nlp_3D_x[0] if nlp_3D_x.shape[0] == 1 else None # happens when nlp_md GT the last MD of survey
    
    nlp_md_vert += t1_md
    nlp_vert_x = np.array(inslerpolate(survey, tie_in, step=[nlp_md_vert])) #[0]
    nlp_vert =  nlp_vert_x[0] if nlp_vert_x.shape[0] == 1 else None # happens when nlp_md GT the last MD of survey
    
    if nlp_3D is None and nlp_vert is None:
        raise NlpError('The calculated NLP is beyond the last wellbore survey station.')
    
    if nlp_3D is None:
        idx_min = 1
    elif nlp_vert is None:
        idx_min = 0 
    else:
        idx_min = np.argmin([np.abs(nlp_3D[1] - 90.0), np.abs(nlp_vert[1] - 90.0)]) # finds the md that is closest to 90 degrees
    
    best_nlp_md = [nlp_md_3D, nlp_md_vert][idx_min]
    
    return best_nlp_md # div_pos_log[gteq_max_inc_idx,0] + _relative_3D_nlp_md(k_mean, t0, t1)
