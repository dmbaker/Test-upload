import os
import numpy as np

from ..math.utils import modulus, quantize
from ..geometry.utils import toUnitDir, toSpherical, slerp, slerp2

class SurveyError(Exception):
    pass

class SurveyWarning(UserWarning):
    pass

def S_and_T_survey():
    """
    The test survey from Compendium One.
    """
    P1 = np.array([40.00, 40.00, 700.00]) # position at start (tie-in)
    srv = np.array([[702.55,  5.50,   45.00], 
                    [1964.57, 29.75,  77.05], 
                    [5086.35, 29.75,  77.05], 
                    [9901.68, 120.00, 285.00]])
    return srv, P1

def S_and_T_pos_log():
    """
    The test survey from Compendium One.
    """
    head =      ['INT',    'MD', 'INC',   'AZI',    'N',      'E',     'V', 'DLS'] 
    pos = np.array([[0,  702.55,  5.50,   45.00,  40.00,    40.00,  700.00, 0.00], 
                    [0, 1964.57,  29.75,  77.05, 154.78,   393.64, 1895.35, 2.00],
                    [1, 4250.00,  29.75,  77.05, 408.84,  1498.82, 3879.60, 0.00],
                    [0, 5086.35,  29.75,  77.05, 501.82,  1903.25, 4605.73, 0.00],
                    [1, 8504.11,  80.89, 300.71, 1967.04, 1033.30, 7050.00, 3.00],
                    [1, 8828.04,  90.00, 297.31, 2123.40,  751.22, 7075.71, 3.00],
                    [1, 9151.97,  99.11, 293.92, 2262.88,  460.41, 7050.00, 3.00],
                    [0, 9901.68, 120.00, 285.00, 2500.00, -200.00, 6800.00, 3.00]])
    return head, pos

def Adams_pos_log():
    """
    Survey Data Obtained from Adams and Charrier (1985)
    """
    md = [3000, 3300, 3600, 3900, 5000, 6000, 7000, 8000, 9000, 10000]
    inc = [2.0, 4.0, 8.0, 12.0, 15.0, 16.0, 17.0, 17.0, 17.0, 17.0]
    azi = [28.0, 10.0, 35.0, 25.0, 30.0, 28.0, 50.0, 20.0, 30.0, 25.0]
    n = [0.0, 14.93, 42.35, 87.74, 314.71, 548.48, 764.35, 996.13, 1260.16, 1519.26]
    e = [0.0, 4.28, 18.07, 43.24, 162.77, 292.18, 469.05, 631.34, 754.46, 889.34]
    v = [3000.0, 3299.58, 3597.92, 3893.32, 4962.85, 5926.47, 6886.22, 7844.36, 8800.87, 9757.22]
    return np.column_stack((md, inc, azi, n, e, v))

def arc2chord(t1, t2, arclen):
    """
    Calculates the relative vector between two survey stations,
    given tangents at the ends of the arc and the arc length between
    the tangents.
    Assumes survey values are correct
    and if arrays of values, the arrays must all be the same length.
    """
    is_scalar = np.ndim(arclen) == 0
    arclen = np.atleast_1d(arclen)
    cnt = len(arclen)
    t1 = np.atleast_2d(t1)
    t2 = np.atleast_2d(t2)
    
    t_add = t1 + t2 # add the tangent vectors; a vector that points to the end of the arc from the start
    lsqrd_t_add = np.einsum('ij,ij->i', t_add, t_add) # the length squared of the vector sum... same as: np.sum(t12*t12, axis=1)
    anti_parallel = lsqrd_t_add == 0 # test for anti-parallel tangent vectors, the singuar case
    lsqrd_t_add[anti_parallel] = 1.0 # set so we prevents div-by-zero when unitizing the direction vector
    len_t_add = np.sqrt(lsqrd_t_add) # the length of the addition vector
    norm_t_add = np.divide(t_add, len_t_add[:,None]) # normalize the addition vector to unit vector pointing to the end of the arc
    
    t_sub = t2 - t1 # subtract the tangent vectors; the chord on a unit circle
    lsqrd_t_sub = np.einsum('ij,ij->i', t_sub, t_sub) # the length squared of the vector subtraction
    len_t_sub = np.sqrt(lsqrd_t_sub) # the length of the subtraction vector
    
    alpha = 2.0 * np.arctan(np.divide(len_t_sub, len_t_add)) # the unoriented angle between the tangent vectors; the arc length on a unit circle
    
    geom_test = len_t_sub < alpha # do the degenerate circle geometry test, the straight hole test
    arc_2_chord = np.ones(cnt) # if degenerte, we are at unity
    arc_2_chord[geom_test] = np.divide(len_t_sub[geom_test], alpha[geom_test]) # where not unity, calc ratio
    
    relative_pos = (arclen * arc_2_chord)[:,None] * norm_t_add # arc-2-chord. For robust numeric evaluation the order of operations here are important
    relative_pos[anti_parallel] = np.array([np.nan, np.nan, np.nan]) # set any singuar cases to nan because they have vanished
    
    return (relative_pos[0], alpha[0]) if is_scalar else (relative_pos, alpha)

def position_log(survey, tie_in, dog_leg_course_length=100, report_raw=False, decimals=None):
    """
    Calculate a position log from a deviation survey and tie-in location.
    survey: a list deviation surveys. [[md_0, inc_0, azi_0], [md_1, inc_1, azi_1],...]
    tie_in: the 3D position of the first survey in survey. [N, E, V] at first survey station
    dog_leg_course_length: a float that is the normalisation length to calculate dogleg
        severity, e.g., 100 -> degrees per 100 feet, 30 -> degrees per 30 meters.
    report_raw: how to report the resulting position log.
    decimals: an interger.  The number of decimals to round the relative positions
        before they are cumsum'ed to the absolute positions.  This limits the precision of the
        values propagated with increasing MD.
    """
    survey = np.array(survey)
    md = survey[:,0]
    if np.all(md[:1] > md[:-1]):
        raise SurveyError('All measured depths must be strictly increasing.')
        
    arclen = md[1:] - md[:-1]
    if np.any(arclen <= 0.0):
        raise SurveyError('All arclens must be GT 0.')
    
    inc = modulus(survey[:,1], 180.0)
    if not np.all(inc == survey[:,1]):
        raise SurveyWarning('One or more inclination values are not GTEQ 0 and LT 180.')
    
    az = modulus(survey[:,2], 360.0)
    if not np.all(az == survey[:,2]):
        raise SurveyWarning('One or more azimuth values are not GTEQ 0 and LT 360.')
    
    tangents = toUnitDir(inc, az)
    rela_pos, alpha = arc2chord(tangents[:-1], tangents[1:], arclen)
    if(not decimals is None):
        rela_pos = np.around(rela_pos, decimals=decimals)
    
    pos = tie_in + np.cumsum(rela_pos, axis=0)
    pos = np.concatenate(([tie_in], pos), axis=0)
    
    if report_raw:
        angle = np.concatenate(([0.0], alpha))
        k = np.concatenate(([0.0], np.divide(alpha, arclen)))
        return np.column_stack((md, tangents, pos, angle, k))
    else:
        dog_leg = np.concatenate(([0.0], (np.rad2deg(alpha) * dog_leg_course_length / arclen)))
        return np.column_stack((md, inc, az, pos, dog_leg))

def inslerpolate_new(survey, tie_in, step=None, dog_leg_course_length = 100, report_raw=False, decimals=None):
    """
    Interpolate a deviation survey via slerp.
    survey: a list deviation surveys. [[md_0, inc_0, azi_0], [md_1, inc_1, azi_1],...]
    tie_in: the 3D position of the first survey in survey. [N, E, V] at first survey station
    step: the step size to interpolate the survey at, or a list of depths to interpolate.
        If step is None, just calculate the survey position log.
    dog_leg_course_length: a float that is the normalisation length to calculate dogleg
        severity, e.g., 100 -> degrees per 100 feet, 30 -> degrees per 30 meters.
    report_raw: how to report the resulting position.
    decimals: an interger.  The number of decimals to round the relative positions
        before they are cumsum'ed to the absolute positions.  This limits the precision of the
        values propagated with increasing MD.
    """
    survey = np.array(survey)
    if step is None: # no interpolation
        return position_log(survey, tie_in, report_raw=report_raw, decimals=decimals) # so just return the position log
    pos_log = position_log(survey, tie_in, report_raw=True, decimals=decimals)

    mds = pos_log[:,0]
    tangents = pos_log[:,1:4]
    angles = pos_log[:,7]

    if np.ndim(step) == 0:
        quant_ends = quantize([mds[0], mds[-1]], step)
        interp_depths = np.arange(quant_ends[0], quant_ends[1] + step, step)
    else:
        interp_depths = np.atleast_1d(step)

    interp_depths = interp_depths[(interp_depths >= mds[0]) & (interp_depths <= mds[-1])] # make sure we are in range
    
    # get the indexes of the begining and ending stations for each interpolated point that the points falls in
    # a md will be GTEQ to the begining and LT the end of the segment
    interp_idx_b = np.searchsorted(mds[:-1], interp_depths, side='right') # indexes of the would-be end interpolated points
    interp_idx_a = (interp_idx_b - 1) # move the 'b' indexes to the begining of the segments

    t = (interp_depths - mds[interp_idx_a]) / (mds[interp_idx_b] - mds[interp_idx_a]) # fraction in each segment of interp points
    v_0 = tangents[interp_idx_a]
    v_1 = tangents[interp_idx_b]
    ang = angles[interp_idx_b] # angle at the end of the segment. we could calc from v_0 and v_1 but we have it already
    v_i = slerp2(t, v_0, v_1, ang) # get the tangents at the interpolated points
    inc_azi = toSpherical(v_i) # get the inc and azi of the interpolated tangents
    srv_itp = np.column_stack((interp_depths, inc_azi)) # [[md_0, inc_0, azi_0], [md_1, inc_1, azi_1],...] surveys at interp points
    
    srv_mrg_dict = {srv[0]: srv for srv in survey} # a dict of our original surveys keyed by md
    srv_itp_dict = {srv[0]: srv for srv in srv_itp}  # a dict of our interpolated surveys keyed by md
    srv_mrg_dict.update(srv_itp_dict) # merge the original and interpolated removing potential duplicated depths
    srv_cmb = [srv_mrg_dict[md] for md in sorted(srv_mrg_dict.keys())] # combined list of surveys in md order

    pos_log = position_log(srv_cmb, tie_in, dog_leg_course_length=dog_leg_course_length, report_raw=report_raw, decimals=decimals) # calc the postions of the interpolated points
    pos_log_dict = {pos[0]: pos for pos in pos_log} # dict of pos log keyed by md
    interp_pos_logs = [pos_log_dict[md]  for md in interp_depths] # get the interpolated postion log

    return np.array(interp_pos_logs)

def inslerpolate_org(survey, tie_in, step=None, report_raw=False):
    """
    Interpolate a deviation survey via slerp.
    survey: a list deviation surveys.
    tie_in: the 3D position of the first survey in survey.
    step: the step size to interpolate the survey at, or a list of depths to interpolate.
    If step is None, just calculate the survey.
    report_raw: how to report the resulting position.
    """
    if step is None:
        return position_log(survey, tie_in, report_raw=report_raw)
    pos_log = position_log(survey, tie_in, report_raw=True)

    mds = pos_log[:,0]
    tangents = pos_log[:,1:4]
    tie_ins = pos_log[:,4:7]
    angles = pos_log[:,7]
    
    if np.ndim(step) == 0:
        quant_ends = quantize([mds[0], mds[-1]], step)
        interp_depths = np.arange(quant_ends[0], quant_ends[1] + step, step)
    else:
        interp_depths = np.atleast_1d(step)
    
    interp_pos_logs = []
    
    segment_cnt = len(mds) - 1
    for i in np.arange(segment_cnt):
        md1, md2 = mds[i:i+2]
        v0, v1 = tangents[i:i+2]
        
        if (i < segment_cnt  - 1):
            mds_i = interp_depths[(interp_depths >= md1) & (interp_depths < md2)]
        else:
            mds_i = interp_depths[(interp_depths >= md1) & (interp_depths <= md2)]
            
        if len(mds_i) == 0:
            continue
            
        strip_head = mds_i[0] != md1
        if strip_head:
            strip_head = True
            mds_i = np.concatenate([[md1], mds_i])
        strip_tail = mds_i[-1] != md2
        if strip_tail:
            strip_tail = True
            mds_i = np.concatenate([mds_i, [md2]])
    
        t = (mds_i - md1) / (md2 - md1)
        #ang = angles[i+1]
        #v_i = slerp(t, v0, v1, ang)
        v_i = slerp(t, v0, v1)
        inc_az_i = toSpherical(v_i)
        srv_i = np.column_stack((mds_i, inc_az_i))
        tie_in_i = tie_ins[i]
        pos_log_i = position_log(srv_i, tie_in_i, report_raw=report_raw)
        
        if strip_head:
            pos_log_i = pos_log_i[1:]
        if strip_tail:
            pos_log_i = pos_log_i[:-1]
        interp_pos_logs.append(pos_log_i)
        
    return interp_pos_logs if len(interp_pos_logs) == 0 else np.concatenate(interp_pos_logs, axis=0)

def inslerpolate(survey, tie_in, step=None, report_raw=False):
    """
    Interpolate a deviation survey via slerp.
    survey: a list deviation surveys.
    tie_in: the 3D position of the first survey in survey.
    step: the step size to interpolate the survey at, or a list of depths to interpolate.
    If step is None, just calculate the survey.
    report_raw: how to report the resulting position.
    """
    if step is None:
        return position_log(survey, tie_in, report_raw=report_raw)
    pos_log = position_log(survey, tie_in, report_raw=True)

    mds = pos_log[:,0]
    tangents = pos_log[:,1:4]
    
    if np.ndim(step) == 0:
        quant_ends = quantize([mds[0], mds[-1]], step)
        interp_depths = np.arange(quant_ends[0], quant_ends[1] + step, step)
    else:
        interp_depths = np.atleast_1d(step)
    
    interp_pos_logs = []
    md_out = []
    vi_out = []
    
    segment_cnt = len(mds) - 1
    for i in np.arange(segment_cnt):
        md0, md1 = mds[i:i+2]
        v0, v1 = tangents[i:i+2]
        
        if (i < segment_cnt  - 1):
            mds_i = interp_depths[(interp_depths >= md0) & (interp_depths < md1)]
        else:
            mds_i = interp_depths[(interp_depths >= md0) & (interp_depths <= md1)]
        
        # append the start of the arc
        md_out.extend([md0])
        vi_out.extend(list(np.atleast_2d(v0).reshape(-1)))
        if len(mds_i) == 0:
            # no md's to interpolate so append just the endpoint
            md_out.extend([md1])
            vi_out.extend(list(np.atleast_2d(v1).reshape(-1)))
            continue
    
        t = np.atleast_1d((mds_i - md0) / (md1 - md0))
        v_i = slerp(t, v0, v1)

        if mds_i[0] == md0:
            # the first interped depth is the start of the so we already have the start of the arc
            mds_i = mds_i[1:]
            v_i = v_i[1:]
        
        if len(mds_i) > 0:
            md_out.extend(list(np.atleast_1d(mds_i).flat))
            vi_out.extend(list(np.atleast_2d(v_i).flat))
    
    md_out = np.array(md_out)
    vi_out = np.array(vi_out).reshape(-1, 3)
    inc_az = toSpherical(vi_out)
    srv_cmb = np.column_stack((md_out, inc_az))
    pos_log_cmb = position_log(srv_cmb, tie_in, report_raw=report_raw)
    interp_pos_logs = [p for p in pos_log_cmb if p[0] in interp_depths]
    
    return interp_pos_logs

def project(survey, tie_in, to_md, curvature=None, report_raw=False, decimals=None):
    """
    Project a deviation survey to a measured depth beyond the last survey station.
    Returns a deviation survey with the projected survey appended to the end.
    If curvature is None, the curvature from the last arc of the survey is used.
    decimals: an interger.  The number of decimals to round the relative positions
        before they are cumsum'ed to the absolute positions.  This limits the precision of the
        values propagated with increasing MD.
    """
    survey = np.asarray(survey)
    pos_log = position_log(survey, tie_in, report_raw=True, decimals=decimals)[-2:] # grab the last two surveys
    
    mds = pos_log[:,0]
    tangents = pos_log[:,1:4]
    angles = pos_log[:,7]
    
    if curvature is None:
        curvature = angles[1] / (mds[1] - mds[0]) # alpha / course_length
    
    if curvature <= 0: # straight hole
        sta_proj = np.concatenate([[to_md], toSpherical(tangents[1])])
        srv_plus = np.concatenate([survey, [sta_proj]], axis=0)
        return position_log(srv_plus, tie_in, report_raw=report_raw, decimals=decimals)
    
    t = (to_md - mds[1]) / (mds[1] - mds[0])
    ang = curvature * (mds[1] - mds[0])
    v_i = slerp(t, tangents[0], tangents[1], ang)
    sta_proj = np.concatenate([[to_md], toSpherical(v_i)])
    srv_plus = np.concatenate([survey, [sta_proj]], axis=0)
    return position_log(srv_plus, tie_in, report_raw=report_raw, decimals=decimals)

def verticalSection(vs_azimuth):
    """
    Calculates the vertical section of point or set of survey positions.
    http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
    Paragraph 9: Applications of Cross-Products to Geometrical Problems, #2
    vs_azimuth: the azimuth, in degrees, of the vertical section.
    """
    def _pee_cross(p):
        """
        http://people.eecs.berkeley.edu/~wkahan/MathH110/Cross.pdf
        p: a column vector.
        """
        return np.matrix([[0.0, -p[2], p[1]], [p[2], 0.0, -p[0]], [-p[1], p[0], 0.0]])
    
    az = toUnitDir(90.0, vs_azimuth)
    #u = np.matrix([0.0, 0.0, 0.0]).T # we don't need this as u is always the origin
    v = np.matrix([0.0, 0.0, 1.0]).T
    w = np.matrix(az).T # vector in horizontal plane pointing in the azimuth direction
    p = _pee_cross(v) * w
    pd = p.T * p
    
    def _f(y):
        """
        y: an array of 3D vectors, the position of the points, from the survey,
        relative to the origin of the survey.
        """
        z = y.T - p * p.T * y.T / pd # for the case of VS this in most cases will probably be more stable 
        z = np.asarray(z.T)
        z[:,2] = 0.0
        return np.dot(z, az)
    return _f

def position_log_meta(report_raw=False):
    """
    returns a list of the names of the columns in the position_log
    and an empty record. Can be used to build a dataframe for the
    stats pak.
    """
    if report_raw:
        position_log_names = [
            'md', 
            't_n', 't_e', 't_v', 
            'pos_n', 'pos_e', 'pos_v', 
            'angle'
            'k'
        ]

        empty_position_log_rec = [
            np.nan,
            np.nan, np.nan, np.nan,
            np.nan, np.nan, np.nan,
            np.nan, 
            np.nan
        ]
    else:
        position_log_names = [
            'md', 
            'inc', 
            'azi',
            'pos_n', 'pos_e', 'pos_v', 
            'dog_leg'
        ]

        empty_position_log_rec = [
            np.nan,
            np.nan, 
            np.nan,
            np.nan, np.nan, np.nan,
            np.nan
        ]

    return {'names': position_log_names, 'empty_rec': empty_position_log_rec}